# Demo media attribution

The downloaded samples are Blender Foundation open-film trailers:

- **Big Buck Bunny**, © 2008 Blender Foundation, directed by Sacha Goedegebure.
  Project: https://peach.blender.org/
  Sample file: https://media.w3.org/2010/05/bunny/trailer.mp4
- **Sintel**, © 2010 Blender Foundation, directed by Colin Levy.
  Project and licensing: https://durian.blender.org/about/
  Sample file: https://media.w3.org/2010/05/sintel/trailer.mp4

License: Creative Commons Attribution 3.0 Unported:
https://creativecommons.org/licenses/by/3.0/

For this prototype, the trailers were resized/letterboxed to 640×360, converted
to 24 fps H.264 baseline with AAC audio, and used in repeating, clock-based
demonstration channels. The footage is not original Retrovision content.

The static tuning patterns, interface assets and application code were created
for this prototype. No paid service, account, or subscription is required.
