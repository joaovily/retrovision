"""Focused regression tests for Retrovision RANDOM surf sampling.

Behavior covered:
- Archive rerolls draw a random year first, then sample a movie within that
  year, so rerolls surface films from every era instead of only the newest
  uploads.
- The local-library rotation includes Kodi movies, not just TV episodes.

Run on the Pi (no Kodi needed; the xbmc modules are stubbed):
    python3 /root/Retrovision/tests/test_surf_sampling.py
"""
import importlib.util
import sys
import tempfile
import time
import types
from pathlib import Path

HERE = Path(__file__).resolve()
CANDIDATES = [Path('/root/.kodi/addons/script.retro.tv'), HERE.parent, HERE.parent.parent]
ADDON_DIR = next(p for p in CANDIDATES if (p / 'default.py').exists())

TMP = Path(tempfile.mkdtemp(prefix='retrotest'))

# ---------- xbmc stubs (must exist before default.py imports) ----------
xbmc = types.ModuleType('xbmc')
xbmc.LOGWARNING = 'warning'
xbmc.LOGERROR = 'error'
xbmc.LOGINFO = 'info'
xbmc.log = lambda *args, **kwargs: None
xbmc.getIPAddress = lambda: '127.0.0.1'
xbmc.getCondVisibility = lambda *args: False
xbmc.executeJSONRPC = lambda *args: '{}'


class _Monitor:
    def waitForAbort(self, *args):
        return True

    def abortRequested(self):
        return True


xbmc.Monitor = _Monitor


class _Player:
    def __init__(self, *args):
        pass


xbmc.Player = _Player

xbmcaddon = types.ModuleType('xbmcaddon')


class _Addon:
    def __init__(self, *args):
        pass

    def getAddonInfo(self, key):
        return {'path': str(ADDON_DIR),
                'profile': 'special://profile/addon_data/script.retro.tv'}.get(key, '')


xbmcaddon.Addon = _Addon

xbmcvfs = types.ModuleType('xbmcvfs')
xbmcvfs.translatePath = lambda path: str(TMP / 'profile')

xbmcgui = types.ModuleType('xbmcgui')
xbmcgui.NOTIFICATION_INFO = 'info'
xbmcgui.NOTIFICATION_ERROR = 'error'


class _Dialog:
    def notification(self, *args, **kwargs):
        pass

    def yesno(self, *args, **kwargs):
        return False

    def select(self, *args, **kwargs):
        return -1

    def textviewer(self, *args, **kwargs):
        pass


xbmcgui.Dialog = _Dialog


class _Keyboard:
    def __init__(self, *args):
        pass


xbmcgui.Keyboard = _Keyboard


class _Window:
    def __init__(self, *args):
        pass

    def getProperty(self, key):
        # Pretend Retrovision is already running so the modal never launches.
        return 'yes' if key == 'Retrovision.Running' else ''

    def setProperty(self, *args):
        pass

    def clearProperty(self, *args):
        pass


xbmcgui.Window = _Window


class _WindowXMLDialog:
    def __init__(self, *args):
        pass


xbmcgui.WindowXMLDialog = _WindowXMLDialog


class _ListItem:
    def __init__(self, *args, **kwargs):
        pass

    def setInfo(self, *args, **kwargs):
        pass

    def setProperty(self, *args, **kwargs):
        pass


xbmcgui.ListItem = _ListItem

sys.modules.update({'xbmc': xbmc, 'xbmcaddon': xbmcaddon,
                    'xbmcvfs': xbmcvfs, 'xbmcgui': xbmcgui})

spec = importlib.util.spec_from_file_location('retro_default', str(ADDON_DIR / 'default.py'))
default = importlib.util.module_from_spec(spec)
spec.loader.exec_module(default)


# ---------- tests ----------
def t_surf_query_has_year():
    for year in (1925, 1968, 2024):
        query = default.archive_surf_query(year)
        assert 'mediatype:movies' in query, query
        assert 'year:{}'.format(year) in query, query


def t_random_year_bounds_and_spread():
    draws = [default.random_archive_year() for _ in range(200)]
    assert default.ARCHIVE_YEAR_MIN == 1900, default.ARCHIVE_YEAR_MIN
    assert default.ARCHIVE_YEAR_MAX == 2026, default.ARCHIVE_YEAR_MAX
    assert all(1900 <= year <= 2026 for year in draws)
    assert len(set(draws)) > 10, 'years do not spread'


def t_random_year_weighted_to_2026():
    draws = [default.random_archive_year() for _ in range(5000)]
    assert min(draws) >= 1900 and max(draws) <= 2026
    old = sum(1 for year in draws if year < 1964)
    new = sum(1 for year in draws if year >= 1964)
    assert new > old * 1.5, (old, new)
    mean = sum(draws) / len(draws)
    assert mean > 1975, mean
    assert min(draws) <= 1940, 'old years never surface'


def t_surf_genre_rotation():
    app = object.__new__(default.RetroTV)
    app.surf_genre_order = list(default.SURF_GENRES)
    app.surf_genre_index = 0
    seen = [default.RetroTV.next_surf_genre(app) for _ in range(len(default.SURF_GENRES))]
    assert set(seen) == set(default.SURF_GENRES), seen
    assert all(first != second for first, second in zip(seen, seen[1:]))
    assert all(genre in default.SURF_GENRES for genre in seen)


def t_surf_query_genre_clause():
    plain = default.archive_surf_query(1955)
    assert 'subject' not in plain, plain
    assert 'collection:feature_films' in plain, plain
    assert 'movie_trailers' in plain, plain
    query = default.archive_surf_query(1955, 'comedy')
    assert 'year:1955' in query and 'Comedy_Films' in query, query
    scifi = default.archive_surf_query(2001, 'sci-fi')
    assert 'science fiction' in scifi, scifi


def t_confidence_rejects_press_conference():
    junk = {'identifier': 'jumanji-junket', 'title': 'Jumanji Press Conference',
            'collection': ['feature_films'], 'date': '1995-01-01'}
    assert default.archive_confidence(junk) == 0
    trailer = {'identifier': 'x-trailer', 'title': 'Some Film Official Trailer',
               'collection': ['feature_films'], 'year': '1990'}
    assert default.archive_confidence(trailer) == 0
    news = {'identifier': 'news1', 'title': 'Nightly News', 'collection': ['tvnews']}
    assert default.archive_confidence(news) == 0


def t_confidence_prefers_clean_honest_title():
    clean = {'identifier': 'fallen-angel-1945', 'title': 'Fallen Angel',
             'collection': ['feature_films', 'moviesandfilms'], 'year': '1945'}
    bootleg = {'identifier': 'shukriya-2004', 'title': 'Shukriya 2004 HEVC X 265 AC 3 Team DDH RG',
               'collection': ['feature_films'], 'year': '2004'}
    assert default.archive_confidence(clean) == 5, default.archive_confidence(clean)
    assert default.archive_confidence(clean) > default.archive_confidence(bootleg)


def t_list_titles_never_crash_matching():
    # Archive.org returns some titles as lists: the exact 18:44 crash.
    listed = {'identifier': 'multi-title', 'title': ['Jumanji Press Conference', 'Jumanji'],
              'collection': ['feature_films'], 'year': '1995'}
    assert default.archive_confidence(listed) == 0
    clean_list = {'identifier': 'fallen', 'title': ['Fallen Angel'],
                  'collection': ['feature_films'], 'year': '1945'}
    assert default.archive_confidence(clean_list) == 5
    assert default.title_words(['Some Film']) == {'some', 'film'}
    assert default.normalized(['Hello, World!']) == 'helloworld'
    assert default.title_matches(['Jumanji', 'Junk'], 'jumanji') is True


def t_confidence_rejects_episode_codes():
    episode = {'identifier': 'journey-s01e03', 'title': 'Personal Journey Through Movies s01e03',
               'collection': ['feature_films'], 'date': '1995-01-01'}
    assert default.archive_confidence(episode) == 0
    part = {'identifier': 'saga-part2', 'title': 'Saga Part 2',
            'collection': ['feature_films'], 'year': '1980'}
    assert default.archive_confidence(part) == 0
    # Ordinary words containing those letters still play.
    assert default.archive_confidence({'identifier': 'escape', 'title': 'Escape',
                                       'collection': ['feature_films'], 'year': '1940'}) > 0


def t_metadata_seconds_parses_variants():
    assert default.metadata_seconds('5400') == 5400
    assert default.metadata_seconds('01:30:00') == 5400
    assert default.metadata_seconds(['90']) == 90
    assert default.metadata_seconds(None) is None
    assert default.metadata_seconds('') is None
    assert default.metadata_seconds('unknown') is None


def t_archive_url_rejects_shorts():
    real_web_json = default.web_json
    app = object.__new__(default.RetroTV)
    try:
        default.web_json = lambda url, headers=None, timeout=12: {
            'files': [{'name': 'clip.mp4', 'size': 50 * 1024 * 1024}],
            'metadata': {'duration': '92'}}
        assert default.RetroTV.archive_video_url(app, 'oneshort') is None
        default.web_json = lambda url, headers=None, timeout=12: {
            'files': [{'name': 'film.mp4', 'size': 100 * 1024 * 1024}],
            'metadata': {'duration': '01:30:00'}}
        url = default.RetroTV.archive_video_url(app, 'realfilm')
        assert url is not None and 'film.mp4' in url, url
        default.web_json = lambda url, headers=None, timeout=12: {
            'files': [{'name': 'mystery.mp4', 'size': 100 * 1024 * 1024}],
            'metadata': {}}
        assert default.RetroTV.archive_video_url(app, 'mystery') is not None
    finally:
        default.web_json = real_web_json


def t_broad_prefers_confident_tier():
    app = object.__new__(default.RetroTV)
    app.archive_collection_sizes = {}
    app.recent_archive_ids = []
    app.archive_query_size = lambda query: 500
    real_web_json = default.web_json
    default.web_json = lambda url, headers=None, timeout=12: {'response': {'docs': [
        {'identifier': 'junket1', 'title': 'Jumanji Press Conference',
         'collection': ['feature_films'], 'licenseurl': '', 'rights': '',
         'creator': 'c', 'date': '1995-01-01', 'year': '1995'},
        {'identifier': 'film1', 'title': 'Fallen Angel',
         'collection': ['feature_films', 'moviesandfilms'], 'licenseurl': '',
         'rights': '', 'creator': 'c', 'date': '1945-01-01', 'year': '1945'},
    ]}}
    try:
        item = default.RetroTV.random_archive_item_broad(app)
    finally:
        default.web_json = real_web_json
    assert item is not None and item['identifier'] == 'film1', item


def t_movie_pick_prefers_genre():
    app = object.__new__(default.RetroTV)
    app.recent_library_files = []
    app.setProperty = lambda *args: None
    app.show_banner = lambda: None
    played = []

    class _Player:
        def play(self, path, item=None, windowed=True):
            played.append(path)

    app.player = _Player()
    real_rpc = default.json_rpc

    def fake_rpc(method, params=None):
        if method == 'VideoLibrary.GetMovies':
            return {'movies': [
                {'title': 'Love Story', 'year': 1970, 'genre': ['Romance'],
                 'file': '/media/romance.mp4'},
                {'title': 'Scary Night', 'year': 1980, 'genre': ['Horror'],
                 'file': '/media/horror.mp4'},
            ]}
        return {}

    default.json_rpc = fake_rpc
    try:
        assert default.RetroTV.play_random_library_movie(app, 'horror') is True
    finally:
        default.json_rpc = real_rpc
    assert played == ['/media/horror.mp4'], played


def t_item_year():
    assert default.item_year({'year': '1955', 'date': ''}, 2000) == '1955'
    assert default.item_year({'year': ['1968'], 'date': ''}, 2000) == '1968'
    assert default.item_year({'date': '1941-12-07T00:00:00Z'}, 2000) == '1941'
    assert default.item_year({}, 1985) == '1985'


def t_pick_rotation_includes_movies():
    assert not hasattr(default.RetroTV, 'play_random_library_episode'), 'episode source must be removed'
    app = object.__new__(default.RetroTV)
    app.surf_genre = 'comedy'
    tried = []
    app.random_archive_item_broad = lambda genre=None: tried.append('archive') or None
    app.play_random_library_movie = lambda genre=None: tried.append('movie') or False
    for _ in range(60):
        app.play_random_pick()
    assert set(tried) == {'archive', 'movie'}, tried


def t_tuning_visible_whenever_nothing_playing():
    now = time.monotonic()
    tv = default.tuning_visible
    # Tune window, idle wait, buffering, stalled playback: always static.
    assert tv('tv', False, now + 10, False, now) is True
    assert tv('tv', True, 0, False, now) is True
    assert tv('tv', False, 0, False, now) is True
    # Playing video past the tune window: static off.
    assert tv('tv', False, 0, True, now) is False
    # Home screen never shows the TV static.
    assert tv('home', False, 0, False, now) is False


def t_launch_idle_waits_for_channel():
    app = object.__new__(default.RetroTV)
    app.surf_idle = False
    app.surf_active = True
    app.pending_surf = True
    app.magic_active = False
    app.magic_playlist = []
    app.magic_index = -1
    app.mode = 'home'
    app.tuning_duration = 0.55
    props = {}
    app.setProperty = lambda key, value='': props.__setitem__(key, value)
    app.setFocusId = lambda control: None
    default.RetroTV.enter_surf_idle(app)
    assert app.mode == 'tv', app.mode
    assert app.surf_idle is True
    assert app.pending_surf is False
    assert props.get('retro.tuning') == 'yes', props
    assert 'PRESS CH' in props.get('retro.program', ''), props


def t_broad_search_stays_in_random_year():
    app = object.__new__(default.RetroTV)
    app.archive_collection_sizes = {}
    app.recent_archive_ids = []
    seen = {}

    def fake_count(query):
        seen['query'] = query
        return 500

    app.archive_query_size = fake_count
    real_web_json = default.web_json

    def fake_web_json(url, headers=None, timeout=12):
        seen['url'] = url
        return {'response': {'docs': [
            {'identifier': 'x', 'title': 'Test Film', 'licenseurl': '',
             'rights': '', 'creator': 'c', 'date': '1955-01-01', 'year': '1955'},
        ]}}

    default.web_json = fake_web_json
    try:
        item = default.RetroTV.random_archive_item_broad(app)
    finally:
        default.web_json = real_web_json
    assert item is not None
    assert 'year:' in seen['query'], seen['query']
    assert item.get('_year') == '1955', item.get('_year')


def t_movie_surf_skips_strm():
    app = object.__new__(default.RetroTV)
    app.recent_library_files = []
    app.setProperty = lambda *args: None
    app.show_banner = lambda: None
    played = []

    class _Player:
        def play(self, path, item=None, windowed=True):
            played.append(path)

    app.player = _Player()
    real_rpc = default.json_rpc

    def fake_rpc(method, params=None):
        if method == 'VideoLibrary.GetMovies':
            return {'movies': [
                {'title': 'Start Retrovision TV', 'year': 2026,
                 'file': '/root/Retrovision/launcher/retrovision-tv.strm'},
                {'title': 'Real Film', 'year': 1955, 'file': '/media/real-film.mp4'},
            ]}
        return {}

    default.json_rpc = fake_rpc
    try:
        assert default.RetroTV.play_random_library_movie(app) is True
    finally:
        default.json_rpc = real_rpc
    assert played == ['/media/real-film.mp4'], played

    def strm_only(method, params=None):
        if method == 'VideoLibrary.GetMovies':
            return {'movies': [
                {'title': 'Start Retrovision TV', 'year': 2026,
                 'file': '/root/Retrovision/launcher/retrovision-tv.strm'},
            ]}
        return {}

    default.json_rpc = strm_only
    try:
        assert default.RetroTV.play_random_library_movie(app) is False
    finally:
        default.json_rpc = real_rpc


def t_random_archive_autoplays_without_rights_dialog():
    app = object.__new__(default.RetroTV)
    app.archive_video_url = lambda identifier, allow_short=False: 'http://example.test/x.mp4'
    app.setProperty = lambda *args: None
    app.show_banner = lambda: None
    played = []

    class _Player:
        def play(self, path, item=None, windowed=True):
            played.append(path)

    app.player = _Player()
    calls = {'yesno': 0}
    real_dialog = default.xbmcgui.Dialog

    class _CountingDialog:
        def notification(self, *args, **kwargs):
            pass

        def yesno(self, *args, **kwargs):
            calls['yesno'] += 1
            return False

    default.xbmcgui.Dialog = _CountingDialog
    try:
        result = default.RetroTV.play_random_archive_item(app, {
            'identifier': 'x', 'title': 'Mystery Film', 'creator': 'Someone',
            '_license': '', '_rights': 'No rights statement was supplied.',
        })
    finally:
        default.xbmcgui.Dialog = real_dialog
    assert result is True
    assert calls['yesno'] == 0, 'rights dialog was shown'
    assert played == ['http://example.test/x.mp4'], played


def t_surf_query_excludes_tv_news():
    query = default.archive_surf_query(1955)
    assert 'NOT' in query and 'tvnews' in query, query


def t_is_news_item():
    assert default.is_news_item({'title': 'CNN Evening News', 'collection': ['tvnews']}) is True
    assert default.is_news_item({'title': 'Evening News Roundup'}) is True
    assert default.is_news_item({'title': 'Newsies'}) is False
    assert default.is_news_item({'title': 'A Quiet Film', 'collection': ['prelinger']}) is False


def t_broad_skips_news_items():
    app = object.__new__(default.RetroTV)
    app.archive_collection_sizes = {}
    app.recent_archive_ids = []
    app.archive_query_size = lambda query: 500
    real_web_json = default.web_json
    default.web_json = lambda url, headers=None, timeout=12: {'response': {'docs': [
        {'identifier': 'news1', 'title': 'Nightly News', 'collection': ['tvnews'],
         'licenseurl': '', 'rights': '', 'creator': 'c', 'date': '1990-01-01', 'year': '1990'},
        {'identifier': 'film1', 'title': 'A Good Film', 'collection': ['prelinger'],
         'licenseurl': '', 'rights': '', 'creator': 'c', 'date': '1955-01-01', 'year': '1955'},
    ]}}
    try:
        item = default.RetroTV.random_archive_item_broad(app)
    finally:
        default.web_json = real_web_json
    assert item is not None and item['identifier'] == 'film1', item


def t_archive_url_prefers_small_files():
    real_web_json = default.web_json
    app = object.__new__(default.RetroTV)
    try:
        default.web_json = lambda url, headers=None, timeout=12: {'files': [
            {'name': 'giant-1080.mp4', 'size': 1500 * 1024 * 1024},
            {'name': 'small-512kb.mp4', 'size': 100 * 1024 * 1024},
        ]}
        url = default.RetroTV.archive_video_url(app, 'someid')
        assert url is not None and 'small-512kb.mp4' in url, url
        default.web_json = lambda url, headers=None, timeout=12: {'files': [
            {'name': 'giant-1080.mp4', 'size': 1500 * 1024 * 1024},
        ]}
        assert default.RetroTV.archive_video_url(app, 'someid') is None
    finally:
        default.web_json = real_web_json


def t_tune_focuses_video_not_guide():
    app = object.__new__(default.RetroTV)
    app.config = {'channels': [{'id': 1, 'name': 'x', 'items': []}], 'media': {}}
    app.state_path = TMP / 'last-channel.json'
    app.tuning_duration = 0.55
    props = {}
    focus = {}
    app.setProperty = lambda key, value='': props.__setitem__(key, value)
    app.setFocusId = lambda control: focus.__setitem__('id', control)
    app.show_banner = lambda: None
    default.RetroTV.tune(app, 0)
    assert focus.get('id') == 210, focus


def t_surf_shows_loading_banner_and_focuses_video():
    app = object.__new__(default.RetroTV)
    app.tuning_duration = 0.55
    props = {}
    focus = {}
    app.setProperty = lambda key, value='': props.__setitem__(key, value)
    app.setFocusId = lambda control: focus.__setitem__('id', control)
    before = time.monotonic()
    app.surf_genre_order = list(default.SURF_GENRES)
    app.surf_genre_index = 0
    default.RetroTV.enter_surf_mode(app)
    assert focus.get('id') == 210, focus
    assert 'TUNING TO' in props.get('retro.program', ''), props
    assert app.surf_genre in default.SURF_GENRES, app.surf_genre
    assert app.surf_genre.upper() in props.get('retro.channel', ''), props
    assert app.banner_until - before > 20, app.banner_until - before


def t_error_rerolls_without_channels():
    app = object.__new__(default.RetroTV)
    app.config = {'channels': [], 'media': {}}
    app.surf_active = False
    app.magic_active = False
    app.mode = 'tv'
    rerolled = []
    app.enter_surf_mode = lambda: rerolled.append(True)
    default.RetroTV.handle(app, 'error', None)
    assert rerolled == [True], rerolled



def t_maybe_start_pick_runs_off_thread():
    import threading
    app = object.__new__(default.RetroTV)
    app.pick_running = False
    done = threading.Event()
    app.play_random_pick = lambda *args: done.set()
    assert default.RetroTV.maybe_start_pick(app) is True
    assert done.wait(5) is True
    deadline = time.monotonic() + 5
    while getattr(app, 'pick_running', True) and time.monotonic() < deadline:
        time.sleep(0.01)
    assert app.pick_running is False
    # A second press mid-roll is dropped instead of piling on.
    app.pick_running = True
    assert default.RetroTV.maybe_start_pick(app) is False

TESTS = [
    ('pick runs off thread', t_maybe_start_pick_runs_off_thread),
    ('surf query constrains a year', t_surf_query_has_year),
    ('random years span every era', t_random_year_bounds_and_spread),
    ('random years weighted to 2026', t_random_year_weighted_to_2026),
    ('surf genre rotation', t_surf_genre_rotation),
    ('surf query genre clause', t_surf_query_genre_clause),
    ('confidence rejects press conference', t_confidence_rejects_press_conference),
    ('list titles never crash matching', t_list_titles_never_crash_matching),
    ('confidence prefers clean honest title', t_confidence_prefers_clean_honest_title),
    ('broad prefers confident tier', t_broad_prefers_confident_tier),
    ('confidence rejects episode codes', t_confidence_rejects_episode_codes),
    ('metadata seconds parses variants', t_metadata_seconds_parses_variants),
    ('archive url rejects shorts', t_archive_url_rejects_shorts),
    ('movie pick prefers genre', t_movie_pick_prefers_genre),
    ('launch idle waits for channel', t_launch_idle_waits_for_channel),
    ('tuning visible whenever nothing playing', t_tuning_visible_whenever_nothing_playing),
    ('item year label', t_item_year),
    ('pick rotation includes movies', t_pick_rotation_includes_movies),
    ('broad search stays in random year', t_broad_search_stays_in_random_year),
    ('movie surf skips strm shims', t_movie_surf_skips_strm),
    ('random archive autoplays without rights dialog', t_random_archive_autoplays_without_rights_dialog),
    ('surf query excludes tv news', t_surf_query_excludes_tv_news),
    ('news item detection', t_is_news_item),
    ('broad search skips news items', t_broad_skips_news_items),
    ('archive url prefers small files', t_archive_url_prefers_small_files),
    ('tune focuses video not guide', t_tune_focuses_video_not_guide),
    ('surf shows loading banner and focuses video', t_surf_shows_loading_banner_and_focuses_video),
    ('error rerolls without channels', t_error_rerolls_without_channels),
]


def main():
    failures = 0
    for name, test in TESTS:
        try:
            test()
        except Exception as exc:
            failures += 1
            print('FAIL {}: {!r}'.format(name, exc))
        else:
            print('PASS {}'.format(name))
    print('{}/{} passed'.format(len(TESTS) - failures, len(TESTS)))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
