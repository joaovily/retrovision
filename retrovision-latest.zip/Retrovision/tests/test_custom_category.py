"""Focused regression tests for the MAGIC custom category lock.

Behavior covered:
- A viewer-typed phrase ("brazilian movies") becomes a 'Custom: <phrase>'
  lock whose Internet Archive clauses search curated collections AND
  individual uploads with no curated-collection gate.
- Custom result matching is deliberately loose (any phrase word in
  title/subject/description/creator) so sparse categories still return hits.
- Plain (non-custom) locks and unknown labels behave exactly as before.

Run on the Pi (no Kodi needed; the xbmc modules are stubbed):
    python3 /root/Retrovision/tests/test_custom_category.py
"""
import importlib.util
import sys
import tempfile
import types
import urllib.parse
from pathlib import Path

HERE = Path(__file__).resolve()
CANDIDATES = [Path('/root/.kodi/addons/script.retro.tv'), HERE.parent, HERE.parent.parent]
ADDON_DIR = next(p for p in CANDIDATES if (p / 'default.py').exists())

TMP = Path(tempfile.mkdtemp(prefix='retrotest'))

# ---------- xbmc stubs (must exist before default.py imports) ----------
xbmc = types.ModuleType('xbmc')
xbmc.LOGWARNING = 'warning'
xbmc.LOGERROR = 'error'
xbmc.LOGINFO = 'info'
xbmc.log = lambda *args, **kwargs: None
xbmc.getIPAddress = lambda: '127.0.0.1'
xbmc.getCondVisibility = lambda *args: False
xbmc.executeJSONRPC = lambda *args: '{}'


class _Monitor:
    def waitForAbort(self, *args):
        return True

    def abortRequested(self):
        return True


xbmc.Monitor = _Monitor


class _Player:
    def __init__(self, *args):
        pass


xbmc.Player = _Player

xbmcaddon = types.ModuleType('xbmcaddon')


class _Addon:
    def __init__(self, *args):
        pass

    def getAddonInfo(self, key):
        return {'path': str(ADDON_DIR),
                'profile': 'special://profile/addon_data/script.retro.tv'}.get(key, '')


xbmcaddon.Addon = _Addon

xbmcvfs = types.ModuleType('xbmcvfs')
xbmcvfs.translatePath = lambda path: str(TMP / 'profile')

xbmcgui = types.ModuleType('xbmcgui')
xbmcgui.NOTIFICATION_INFO = 'info'
xbmcgui.NOTIFICATION_ERROR = 'error'


class _Dialog:
    def notification(self, *args, **kwargs):
        pass

    def yesno(self, *args, **kwargs):
        return False

    def select(self, *args, **kwargs):
        return -1

    def textviewer(self, *args, **kwargs):
        pass


xbmcgui.Dialog = _Dialog


class _Keyboard:
    def __init__(self, *args):
        pass


xbmcgui.Keyboard = _Keyboard


class _Window:
    def __init__(self, *args):
        pass

    def getProperty(self, key):
        # Pretend Retrovision is already running so the modal never launches.
        return 'yes' if key == 'Retrovision.Running' else ''

    def setProperty(self, *args):
        pass

    def clearProperty(self, *args):
        pass


xbmcgui.Window = _Window


class _WindowXMLDialog:
    def __init__(self, *args):
        pass


xbmcgui.WindowXMLDialog = _WindowXMLDialog


class _ListItem:
    def __init__(self, *args, **kwargs):
        pass

    def setInfo(self, *args, **kwargs):
        pass

    def setProperty(self, *args, **kwargs):
        pass


xbmcgui.ListItem = _ListItem

sys.modules.update({'xbmc': xbmc, 'xbmcaddon': xbmcaddon,
                    'xbmcvfs': xbmcvfs, 'xbmcgui': xbmcgui})

spec = importlib.util.spec_from_file_location('retro_default', str(ADDON_DIR / 'default.py'))
default = importlib.util.module_from_spec(spec)
spec.loader.exec_module(default)


# ---------- tests ----------
def t_custom_phrase_parsing():
    assert default.custom_category_phrase('Custom: brazilian movies') == 'brazilian movies'
    assert default.custom_category_phrase('custom:  silent comedy  ') == 'silent comedy'
    assert default.custom_category_phrase('Comedy') is None
    assert default.custom_category_phrase('') is None
    assert default.custom_category_phrase(None) is None
    assert default.custom_category_phrase('Custom:   ') is None


def t_custom_clauses_unrestricted():
    clauses = default.custom_category_clauses('brazilian movies')
    assert len(clauses) == 2, clauses
    joined = ' '.join(clauses).lower()
    assert 'brazilian' in joined and 'movies' in joined, clauses
    # No curated-collection gate: individual uploads must be reachable.
    assert 'feature_films' not in joined, clauses
    assert 'collection:' in joined and 'title:' in joined, clauses
    assert default.custom_category_clauses('  ') == []


def t_custom_entry_and_clauses_roundtrip():
    entry = default.category_lock_entry('Custom: brazilian movies')
    assert entry['label'] == 'Custom: brazilian movies', entry
    assert 'brazilian' in entry['kodi'] and 'movies' in entry['kodi'], entry
    tiers = default.category_lock_clauses('Custom: brazilian movies')
    assert len(tiers) == 2, tiers
    # Plain locks and unknown labels are untouched.
    assert default.category_lock_entry('Comedy')['label'] == 'Comedy'
    assert default.category_lock_entry('No Such Lock') is default.CATEGORY_LOCKS[0]
    assert default.category_lock_clauses('') == []


def t_custom_result_matching_is_loose():
    phrase = 'brazilian movies'
    assert default.custom_result_matches(
        {'title': 'Os Trapalhoes', 'description': 'A classic Brazilian comedy film'}, phrase)
    assert default.custom_result_matches(
        {'title': 'Something Else', 'creator': 'Movies from Brazil archive'}, phrase)
    assert not default.custom_result_matches(
        {'title': 'Space Adventure', 'description': 'A sci-fi western'}, phrase)
    assert not default.custom_result_matches({'title': 'No text anywhere'}, phrase)


def t_custom_result_ranking_prefers_exact_title():
    phrase = 'samurai cinema'
    exact = {'title': 'Samurai Cinema Classics', 'description': 'old films'}
    loose = {'title': 'LG Cinema Smart TV Lineup', 'description': 'news segment'}
    assert default.custom_result_score(exact, phrase) > default.custom_result_score(loose, phrase)
    assert default.custom_result_score(loose, phrase) > 0


def t_custom_search_has_no_title_gate():
    # Broad by design: every returned doc is kept, best match ranked first.
    seen = []

    def fake_web_json(url):
        seen.append(url)
        return {'response': {'docs': [
            {'identifier': 'a2', 'title': 'Totally Unrelated Space Film',
             'description': 'nothing in common here'},
            {'identifier': 'a1', 'title': 'Brazilian Cinema Classics',
             'description': 'brazilian movies collection'},
        ]}}

    app = object.__new__(default.RetroTV)
    app.category_lock = 'Custom: brazilian movies'
    original = default.web_json
    default.web_json = fake_web_json
    try:
        results = default.RetroTV.archive_search(app, 'anything at all')
    finally:
        default.web_json = original
    assert seen, 'no archive query was issued'
    assert [doc['identifier'] for doc in results] == ['a1', 'a2'], results


def t_custom_archive_search_queries_and_filter():
    seen = []

    def fake_web_json(url):
        seen.append(url)
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)['q'][0]
        assert 'feature_films' not in query, query
        return {'response': {'docs': [
            {'identifier': 'a1', 'title': 'Brazilian Cinema Classics',
             'description': 'brazilian movies collection'},
            {'identifier': 'a2', 'title': 'Totally Unrelated Space Film',
             'description': 'nothing in common here'},
        ]}}

    app = object.__new__(default.RetroTV)
    app.category_lock = 'Custom: brazilian movies'
    original = default.web_json
    default.web_json = fake_web_json
    try:
        default.RetroTV.archive_search(app, 'anything at all')
    finally:
        default.web_json = original
    assert seen, 'no archive query was issued'


def t_web_search_url_shape():
    url = default.web_search_url('charlie chaplin')
    assert url.startswith('https://www.google.com/search?q='), url
    assert 'charlie' in url and 'chaplin' in url, url
    assert ' ' not in url, url


def _fallback_app(accept):
    class _Dialog:
        def notification(self, *args, **kwargs):
            pass

        def yesno(self, *args, **kwargs):
            return accept

        def select(self, *args, **kwargs):
            return -1

        def textviewer(self, *args, **kwargs):
            pass

    app = object.__new__(default.RetroTV)
    app.category_lock = ''
    app.web_fallback = None
    app.mode = 'home'
    app.config = {'channels': [], 'media': {}}
    return app, _Dialog


def t_web_fallback_accepted_when_archive_empty():
    app, dialog = _fallback_app(True)
    original_dialog = default.xbmcgui.Dialog
    original_web = default.web_json
    default.xbmcgui.Dialog = dialog
    default.web_json = lambda url: {'response': {'docs': []}}
    try:
        assert default.RetroTV.choose_archive_result(app, 'charlie chaplin') is True
    finally:
        default.xbmcgui.Dialog = original_dialog
        default.web_json = original_web
    assert app.web_fallback['query'] == 'charlie chaplin', app.web_fallback
    assert app.web_fallback['url'] == default.web_search_url('charlie chaplin')
    state = default.RetroTV.remote_state(app)
    assert state['web_search'] == app.web_fallback, state


def t_web_fallback_declined_leaves_no_link():
    app, dialog = _fallback_app(False)
    original_dialog = default.xbmcgui.Dialog
    original_web = default.web_json
    default.xbmcgui.Dialog = dialog
    default.web_json = lambda url: {'response': {'docs': []}}
    try:
        assert default.RetroTV.choose_archive_result(app, 'charlie chaplin') is False
    finally:
        default.xbmcgui.Dialog = original_dialog
        default.web_json = original_web
    assert app.web_fallback is None
    assert default.RetroTV.remote_state(app)['web_search'] is None


def t_unrestricted_surf_query_drops_collection_gate():
    app = object.__new__(default.RetroTV)
    app.recent_archive_ids = []
    seen = []
    app.archive_query_size = lambda query: seen.append(query) or 0
    clauses = default.custom_category_clauses('brazilian movies')
    assert default.RetroTV.random_archive_item_broad(
        app, None, clauses, True) is None
    assert seen, 'no surf query was issued'
    for query in seen:
        assert 'feature_films' not in query, query
        assert 'mediatype:movies' in query, query
        assert 'brazilian' in query, query


def t_unrestricted_surf_skips_confidence_filter():
    junk = {'identifier': 'x-trailer', 'title': 'Some Film Official Trailer',
            'collection': ['feature_films'], 'date': '1995-01-01'}
    clauses = default.custom_category_clauses('trailer')
    original = default.web_json
    default.web_json = lambda url: {'response': {'docs': [dict(junk)]}}
    try:
        open_app = object.__new__(default.RetroTV)
        open_app.recent_archive_ids = []
        open_app.archive_query_size = lambda query: 5000
        picked = default.RetroTV.random_archive_item_broad(
            open_app, None, clauses, True)
        strict_app = object.__new__(default.RetroTV)
        strict_app.recent_archive_ids = []
        strict_app.archive_query_size = lambda query: 5000
        dropped = default.RetroTV.random_archive_item_broad(
            strict_app, None, clauses, False)
    finally:
        default.web_json = original
    assert picked is not None and picked['_unrestricted'] is True, picked
    assert dropped is None, dropped


def t_archive_video_url_allow_short():
    app = object.__new__(default.RetroTV)
    meta = {'metadata': {'duration': '65'},
            'files': [{'name': 'clip.mp4', 'size': '5000000'}]}
    original = default.web_json
    default.web_json = lambda url: meta
    try:
        blocked = default.RetroTV.archive_video_url(app, 'some-short')
        allowed = default.RetroTV.archive_video_url(app, 'some-short', True)
    finally:
        default.web_json = original
    assert blocked is None, blocked
    assert allowed == 'https://archive.org/download/some-short/clip.mp4', allowed


def _provider_router(calls):
    def fake_web_json(url):
        calls.append(url)
        if 'commons.wikimedia.org' in url:
            return {'query': {'pages': {
                '1': {'pageid': 1, 'title': 'File:Chaplin_Test.mp4',
                      'imageinfo': [{'mime': 'video/mp4', 'size': '5000000',
                                     'url': 'https://upload.wikimedia.org/x.mp4',
                                     'extmetadata': {'LicenseShortName': {'value': 'CC0'}}}]},
                '2': {'pageid': 2, 'title': 'File:Chaplin_Clip.webm',
                      'imageinfo': [{'mime': 'video/webm', 'size': '8000000',
                                     'url': 'https://upload.wikimedia.org/x.webm'}]},
                '3': {'pageid': 3, 'title': 'File:Chaplin_Song.ogg',
                      'imageinfo': [{'mime': 'audio/ogg', 'size': '5000000',
                                     'url': 'https://upload.wikimedia.org/x.ogg'}]},
                '4': {'pageid': 4, 'title': 'File:Chaplin_Huge.mp4',
                      'imageinfo': [{'mime': 'video/mp4', 'size': str(2 * 1024 * 1024 * 1024),
                                     'url': 'https://upload.wikimedia.org/huge.mp4'}]},
            }}}
        if '/api/v1/videos/' in url:
            return {'files': [
                {'fileUrl': 'https://pt.tv/big.mp4', 'size': 2 * 1024 * 1024 * 1024},
                {'fileUrl': 'https://pt.tv/ok.mp4', 'size': '9000000'}]}
        if 'peertube.tv/api/v1/search' in url:
            return {'data': [
                {'uuid': 'nsfw1', 'nsfw': True, 'privacy': {'id': 1},
                 'name': 'NSFW', 'licence': {'label': 'CC BY'}},
                {'uuid': 'priv1', 'nsfw': False, 'privacy': {'id': 2},
                 'name': 'Private', 'licence': {'label': 'CC BY'}},
                {'uuid': 'ok1', 'nsfw': False, 'privacy': {'id': 1},
                 'name': 'Chaplin Tribute', 'licence': {'label': 'CC BY-NC 4.0'},
                 'account': {'displayName': 'Fan'},
                 'truncatedDescription': 'a tribute film'},
            ]}
        if 'advancedsearch.php' in url:
            return {'response': {'docs': [
                {'identifier': 'ia1', 'title': 'Chaplin Archive Film',
                 'description': 'chaplin comedy film'},
            ]}}
        raise AssertionError('unexpected url ' + url)
    return fake_web_json


def t_commons_search_maps_and_gates():
    calls = []
    original = default.web_json
    default.web_json = _provider_router(calls)
    try:
        results = default.commons_search('chaplin')
    finally:
        default.web_json = original
    assert [doc['identifier'] for doc in results] == ['commons:1', 'commons:2'], results
    assert results[0]['title'] == 'Chaplin Test', results
    assert results[0]['_source'] == 'commons'
    assert results[0]['_file_url'] == 'https://upload.wikimedia.org/x.mp4'
    assert 'CC0' in results[0]['_rights'], results


def t_peertube_search_skips_nsfw_private_unplayable():
    calls = []
    original = default.web_json
    default.web_json = _provider_router(calls)
    try:
        results = default.peertube_search('chaplin')
    finally:
        default.web_json = original
    assert [doc['identifier'] for doc in results] == ['peertube:ok1'], results
    assert results[0]['_file_url'] == 'https://pt.tv/ok.mp4', results
    assert 'CC BY-NC 4.0' in results[0]['_rights'], results
    assert results[0]['creator'] == 'Fan', results


def t_locked_search_merges_all_providers():
    calls = []
    app = object.__new__(default.RetroTV)
    app.category_lock = 'Custom: chaplin comedy'
    original = default.web_json
    default.web_json = _provider_router(calls)
    try:
        results = default.RetroTV.archive_search(app, 'chaplin')
    finally:
        default.web_json = original
    sources = [doc.get('_source', 'archive') for doc in results]
    assert 'archive' in sources and 'commons' in sources and 'peertube' in sources, sources
    assert any('commons.wikimedia.org' in url for url in calls), calls
    assert any('peertube.tv' in url for url in calls), calls


def t_unlocked_search_ignores_external_providers():
    calls = []
    app = object.__new__(default.RetroTV)
    app.category_lock = ''
    original = default.web_json
    default.web_json = _provider_router(calls)
    try:
        results = default.RetroTV.archive_search(app, 'chaplin')
    finally:
        default.web_json = original
    assert calls and all('advancedsearch.php' in url for url in calls), calls
    assert [doc['identifier'] for doc in results] == ['ia1'], results


def t_preset_lock_keeps_externals_visible():
    calls = []
    app = object.__new__(default.RetroTV)
    app.category_lock = 'Comedy'
    original = default.web_json
    default.web_json = _provider_router(calls)
    try:
        results = default.RetroTV.archive_search(app, 'chaplin comedy')
    finally:
        default.web_json = original
    sources = [doc.get('_source', 'archive') for doc in results]
    assert 'commons' in sources and 'peertube' in sources, sources
    assert len(results) <= 25, len(results)


def t_result_video_url_prefers_direct_file():
    app = object.__new__(default.RetroTV)
    direct = {'identifier': 'commons:1', '_file_url': 'https://upload.wikimedia.org/x.mp4'}
    assert default.RetroTV.result_video_url(app, direct) == 'https://upload.wikimedia.org/x.mp4'
    app.archive_video_url = lambda identifier, allow_short=False: 'http://example.test/x.mp4'
    plain = {'identifier': 'ia1'}
    assert default.RetroTV.result_video_url(app, plain) == 'http://example.test/x.mp4'


TESTS = [value for name, value in sorted(globals().items())
         if name.startswith('t_') and callable(value)]

if __name__ == '__main__':
    failed = 0
    for test in TESTS:
        try:
            test()
        except AssertionError as exc:
            failed += 1
            print('FAIL {}: {!r}'.format(test.__name__, exc))
        else:
            print('ok {}'.format(test.__name__))
    print('{} passed, {} failed'.format(len(TESTS) - failed, failed))
    sys.exit(1 if failed else 0)
