"""Focused tests for Reddit Natural Search (reddit/{term} custom category).

Covers: input parsing, subreddit scoring, random/text-only/multi-word
edge cases, and video-post shaping. No network: web_json is stubbed.

Run: python3 test_reddit_search.py
"""
import importlib.util
import sys
import tempfile
import types
from pathlib import Path

HERE = Path(__file__).resolve()
CANDIDATES = [Path('/root/.kodi/addons/script.retro.tv'), HERE.parent,
              HERE.parent.parent,
              Path(r'C:\Users\newco\retrovision-work\.kodi\addons\script.retro.tv')]
ADDON_DIR = next(p for p in CANDIDATES if (p / 'default.py').exists())

TMP = Path(tempfile.mkdtemp(prefix='retrotest'))

xbmc = types.ModuleType('xbmc')
xbmc.LOGWARNING = 'warning'
xbmc.LOGERROR = 'error'
xbmc.LOGINFO = 'info'
xbmc.log = lambda *a, **k: None
xbmc.getIPAddress = lambda: '127.0.0.1'
xbmc.getCondVisibility = lambda *a: False
xbmc.executeJSONRPC = lambda *a: '{}'


class _Monitor:
    def waitForAbort(self, *a):
        return True

    def abortRequested(self):
        return True


xbmc.Monitor = _Monitor


class _Player:
    def __init__(self, *a):
        pass


xbmc.Player = _Player
sys.modules['xbmc'] = xbmc
xbmcaddon = types.ModuleType('xbmcaddon')


class _Addon:
    def __init__(self, *a):
        pass

    def getAddonInfo(self, key):
        return {'path': str(ADDON_DIR), 'profile': str(TMP)}.get(key, '')


xbmcaddon.Addon = _Addon
sys.modules['xbmcaddon'] = xbmcaddon
xbmcvfs = types.ModuleType('xbmcvfs')
xbmcvfs.translatePath = lambda path: str(TMP / 'profile')
sys.modules['xbmcvfs'] = xbmcvfs
xbmcgui = types.ModuleType('xbmcgui')
xbmcgui.NOTIFICATION_INFO = 'info'
xbmcgui.NOTIFICATION_ERROR = 'error'


class _Dialog:
    def notification(self, *a, **k):
        pass

    def yesno(self, *a, **k):
        return False

    def select(self, *a, **k):
        return -1

    def textviewer(self, *a, **k):
        pass


xbmcgui.Dialog = _Dialog


class _Keyboard:
    def __init__(self, *a):
        pass


xbmcgui.Keyboard = _Keyboard


class _Window:
    def __init__(self, *a):
        pass

    def getProperty(self, key):
        return 'yes' if key == 'Retrovision.Running' else ''

    def setProperty(self, *a):
        pass

    def clearProperty(self, *a):
        pass


xbmcgui.Window = _Window


class _WindowXMLDialog:
    def __init__(self, *a):
        pass


xbmcgui.WindowXMLDialog = _WindowXMLDialog


class _ListItem:
    def __init__(self, *a, **k):
        pass

    def setInfo(self, *a, **k):
        pass

    def setProperty(self, *a, **k):
        pass


xbmcgui.ListItem = _ListItem
sys.modules['xbmcgui'] = xbmcgui

spec = importlib.util.spec_from_file_location('default', str(ADDON_DIR / 'default.py'))
default = importlib.util.module_from_spec(spec)
spec.loader.exec_module(default)


def t_parse_basic():
    assert default.reddit_category_query('reddit/dogs') == 'dogs'
    assert default.reddit_category_query('Custom: reddit/dogs') == 'dogs'
    assert default.reddit_category_query('REDDIT/90s commercials') == '90s commercials'
    assert default.reddit_category_query('reddit/  cartoons  ') == 'cartoons'


def t_parse_rejects():
    assert default.reddit_category_query('brazilian movies') is None
    assert default.reddit_category_query('reddit/') is None
    assert default.reddit_category_query('reddit') is None
    assert default.reddit_category_query(None) is None


def t_pick_exact_name_wins():
    cands = [{'display_name': 'dogvideos', 'subscribers': 500000,
              'public_description': 'funny dog clips'},
             {'display_name': 'dogs', 'subscribers': 100,
              'public_description': 'dogs'}]
    assert default.pick_best_subreddit('dogs', cands) == 'dogs'


def t_pick_subscribers_break_ties():
    cands = [{'display_name': 'aaa', 'subscribers': 10,
              'public_description': 'cartoons here'},
             {'display_name': 'bbb', 'subscribers': 999999,
              'public_description': 'cartoons here'}]
    assert default.pick_best_subreddit('cartoons', cands) == 'bbb'


def t_pick_description_keywords():
    cands = [{'display_name': 'zzz1', 'subscribers': 100,
              'public_description': 'unrelated knitting'},
             {'display_name': 'zzz2', 'subscribers': 100,
              'public_description': '90s commercials and retro TV ads'}]
    assert default.pick_best_subreddit('90s commercials', cands) == 'zzz2'


def t_pick_empty_falls_back_to_sanitized():
    assert default.pick_best_subreddit('retro gaming', []) == 'retrogaming'
    assert default.pick_best_subreddit('my-cool-thing', []) == 'my-cool-thing'


def t_random_picks_curated():
    got = default.resolve_subreddit('random', search_fn=lambda q: [])
    assert got in default.REDDIT_CURATED_SUBREDDITS, got


def t_resolve_uses_search_winner():
    cands = [{'display_name': 'OldCommercials', 'subscribers': 50000,
              'public_description': 'old tv ads'}]
    got = default.resolve_subreddit('90s commercials',
                                    search_fn=lambda q: cands)
    assert got == 'OldCommercials'


def t_get_videos_shapes_like_other_channels():
    posts = [{'data': {'id': 'a1', 'title': 'Clip', 'author': 'bob',
                       'selftext': 'x', 'is_video': True,
                       'media': {'reddit_video': {'fallback_url': 'https://v.redd.it/x/DASH_720.mp4?x'}}}},
             {'data': {'id': 'a2', 'title': 'Text post', 'author': 'ann',
                       'selftext': 'hello', 'is_video': False}}]
    orig = default.web_json
    default.web_json = lambda url, headers=None, timeout=12: {'data': {'children': posts}}
    try:
        vids = default.get_reddit_videos('AskReddit', limit=5)
    finally:
        default.web_json = orig
    assert len(vids) == 1, vids
    v = vids[0]
    assert v['identifier'] == 'reddit:a1'
    assert v['title'] == 'Clip'
    assert v['_source'] == 'reddit'
    assert v['_file_url'].startswith('https://v.redd.it/x/')
    assert '?' not in v['_file_url']
    assert 'AskReddit' in v['creator']


TESTS = [v for n, v in sorted(globals().items()) if n.startswith('t_') and callable(v)]

if __name__ == '__main__':
    failed = 0
    for test in TESTS:
        try:
            test()
        except AssertionError as exc:
            failed += 1
            print('FAIL {}: {!r}'.format(test.__name__, exc))
        else:
            print('ok {}'.format(test.__name__))
    print('{} passed, {} failed'.format(len(TESTS) - failed, failed))
    sys.exit(1 if failed else 0)
