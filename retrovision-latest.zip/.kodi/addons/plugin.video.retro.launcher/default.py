import sys

import xbmc
import xbmcplugin

xbmc.executebuiltin('RunScript(script.retro.tv,tv)')
xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
