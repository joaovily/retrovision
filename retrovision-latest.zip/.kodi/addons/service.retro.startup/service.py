import xbmc
import xbmcgui
monitor = xbmc.Monitor()
# Let the skin finish loading before opening the TV window.
for _ in range(60):
    if monitor.waitForAbort(1):
        break
    if xbmc.getCondVisibility('Window.IsActive(home)'):
        if not monitor.waitForAbort(2):
            if xbmcgui.Window(10000).getProperty('Retrovision.Running') != 'yes':
                xbmc.executebuiltin('RunScript(script.retro.tv)')
        break
