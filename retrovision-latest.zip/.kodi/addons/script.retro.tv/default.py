"""Retrovision prototype. Local playback, clock-based channels, paired LAN remote."""
import hmac
import json
import os
import queue
import random
import re
import secrets
import socket
import sys
import threading
import time
import unicodedata
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('script.retro.tv')
ROOT = Path(ADDON.getAddonInfo('path'))
DATA = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
DATA.mkdir(parents=True, exist_ok=True)
CONFIG = DATA / 'channels.json'
PLUTO_CACHE = DATA / 'pluto-catalog.json'
ADDON_INBOX = DATA / 'addon-inbox'
ADDON_INBOX.mkdir(parents=True, exist_ok=True)
EPOCH = 1767225600  # 2026-01-01 UTC: repeatable channel clocks across restarts
# RANDOM samples the curated Feature Films collection (~28k honest films),
# not the whole 17M-item mediatype:movies firehose of test files, templates,
# and spam uploads. Trailers and TV news are excluded. Each reroll first draws
# a recency-weighted year, then samples a title within that year. RANDOM plays
# whatever it rolls with no confirmation step; MAGIC search results still
# confirm unclear rights before playing.
ARCHIVE_SURF_ALL_QUERY = ('mediatype:movies AND collection:feature_films '
                          'AND NOT collection:movie_trailers')
# Custom-category surf base: every Internet Archive video, no curated
# collection gate, so a specific query reaches individual uploads too.
# (mediatype:movies IS the archive's all-video bucket.)
ARCHIVE_CUSTOM_SURF_BASE = 'mediatype:movies'
# Collections whose films are curated and reliably playable.
ARCHIVE_TRUSTED_COLLECTIONS = {'feature_films', 'moviesandfilms', 'silent_films',
                               'short_films', 'Comedy_Films', 'Film_Noir', 'SciFi_Horror',
                               'TheVideoCellarCollection', 'prelinger', 'opensource_movies'}
# Whole-word title markers of non-movies: trailers, clips, interviews, ads.
# A real film title is usually just the movie name.
ARCHIVE_JUNK_TITLE_WORDS = {'trailer', 'trailers', 'preview', 'previews', 'teaser',
                            'interview', 'interviews', 'featurette',
                            'outtakes', 'bloopers', 'commercial', 'commercials',
                            'advertisement', 'unboxing', 'review', 'reviews', 'reaction',
                            'episode', 'episodes', 'clip', 'clips', 'excerpt',
                            'part', 'parts', 'pt', 'cd', 'disc', 'segment'}
# Multi-word non-movie markers, matched against the title with all separators
# stripped, so "Jumanji press conference" hits without banning the everyday
# words "press" or "making" on their own.
ARCHIVE_JUNK_TITLE_PHRASES = {'pressconference', 'behindthescenes', 'makingof'}
# Episode/part/disc markers, full-matched against whole title words (so "Show
# E02" and "s01e03" hit, but ordinary words containing those letters don't):
# TV episodes and multi-part uploads are never movies.
ARCHIVE_JUNK_TITLE_TOKEN_PATTERNS = (re.compile(r's\d{1,3}e\d{1,3}'),
                                     re.compile(r'e?p\d{1,3}'),
                                     re.compile(r'(part|pt|cd|disc|segment)\d{1,3}'))
# Metadata runtimes below this are shorts/clips, not movies. Unknown runtime
# never blocks a pick -- only an explicitly short duration rejects.
ARCHIVE_MIN_RUNTIME = 15 * 60


def metadata_seconds(value):
    """Best-effort seconds from an Archive.org duration/runtime field, which
    arrives as bare seconds ('5400'), a clock string ('01:30:00'), or a list
    of those. Returns None when unknown."""
    if isinstance(value, list):
        value = value[0] if value else None
    text = str(value or '').strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        pass
    try:
        total = 0.0
        for part in text.split(':'):
            total = total * 60 + float(part)
    except ValueError:
        return None
    return total
# Whole-word title markers of bootleg-encode uploads: still a film, but often
# taken down, so they score lower than clean honest titles.
ARCHIVE_CODEC_TITLE_WORDS = {'hevc', 'x265', 'x264', 'bluray', 'webdl', 'dl',
                             'bdrip', 'dvdrip', 'ac3', 'ddh', 'rg', '1080p', '720p', '480p'}


def archive_confidence(document):
    """Confidence 0-5 that an Archive.org document is an honest playable film.
    0 means reject: news (handled separately) or a non-movie title like a
    press conference or trailer. Otherwise clean honest titles in trusted
    collections with a known year score highest; picks prefer the top tier."""
    if is_news_item(document):
        return 0
    title = document.get('title') or ''
    words = title_words(title)
    if words & ARCHIVE_JUNK_TITLE_WORDS:
        return 0
    if any(phrase in normalized(title) for phrase in ARCHIVE_JUNK_TITLE_PHRASES):
        return 0
    if any(pattern.fullmatch(word) for pattern in ARCHIVE_JUNK_TITLE_TOKEN_PATTERNS for word in words):
        return 0
    score = 1
    collections = document.get('collection') or []
    if isinstance(collections, str):
        collections = [collections]
    if any(str(name) in ARCHIVE_TRUSTED_COLLECTIONS for name in collections):
        score += 2
    if words and not (words & ARCHIVE_CODEC_TITLE_WORDS):
        score += 1
    if item_year(document, '') != '':
        score += 1
    return score
ARCHIVE_YEAR_MIN = 1900
ARCHIVE_YEAR_MAX = 2026
ARCHIVE_SURF_YEAR_ATTEMPTS = 10
# One genre per CH press, rotating so every roll lands in another category.
SURF_GENRES = ('comedy', 'romance', 'animation', 'horror', 'drama', 'action',
               'thriller', 'documentary', 'sci-fi', 'western', 'mystery', 'adventure')
# Archive.org subject/genre spellings per category.
ARCHIVE_GENRE_TERMS = {'sci-fi': 'science fiction'}
# Verified genre sub-collections inside Feature Films (checked live against
# archive.org: Comedy_Films, Film_Noir and SciFi_Horror are real curated
# collections). Other categories fall back to subject/genre keywords.
ARCHIVE_GENRE_COLLECTIONS = {'comedy': 'Comedy_Films', 'horror': 'SciFi_Horror',
                             'sci-fi': 'SciFi_Horror', 'mystery': 'Film_Noir'}
# Kodi library genre spellings accepted per category.
KODI_GENRE_TERMS = {'sci-fi': {'sci-fi', 'science fiction', 'sci fi'},
                    'film-noir': {'film-noir', 'noir'}}
# Category Lock: TV-style categories for the MAGIC menu. Each entry maps a UI
# label to Internet Archive query clauses (strict first, broad fallback) plus
# the Kodi library genre words accepted for the same category. A None clause
# means no extra restriction at this tier. Centralized here so search, surf
# and the menu all share one definition.
CATEGORY_LOCKS = (
    {'label': 'All / No category lock', 'strict': None, 'broad': None, 'kodi': frozenset()},
    {'label': 'Movies', 'strict': 'collection:feature_films', 'broad': None, 'kodi': frozenset()},
    {'label': 'Comedy', 'strict': 'collection:Comedy_Films',
     'broad': '(subject:comedy OR genre:comedy OR title:(comedy))', 'kodi': frozenset({'comedy'})},
    {'label': 'Drama', 'strict': '(subject:drama OR genre:drama)',
     'broad': '(title:(drama))', 'kodi': frozenset({'drama'})},
    {'label': 'Action', 'strict': '(subject:action OR genre:action OR subject:adventure)',
     'broad': '(title:(action))', 'kodi': frozenset({'action', 'adventure'})},
    {'label': 'Horror', 'strict': 'collection:SciFi_Horror',
     'broad': '(subject:horror OR genre:horror OR title:(horror))', 'kodi': frozenset({'horror'})},
    {'label': 'Sci-Fi', 'strict': '(subject:science fiction OR genre:science fiction)',
     'broad': '(title:(sci-fi OR "science fiction" OR space))',
     'kodi': frozenset({'sci-fi', 'science fiction', 'sci fi'})},
    {'label': 'Fantasy', 'strict': '(subject:fantasy OR genre:fantasy)',
     'broad': '(title:(fantasy))', 'kodi': frozenset({'fantasy'})},
    {'label': 'Crime', 'strict': '(subject:crime OR genre:crime)',
     'broad': '(title:(crime OR gangster))', 'kodi': frozenset({'crime'})},
    {'label': 'Mystery', 'strict': 'collection:Film_Noir',
     'broad': '(subject:mystery OR genre:mystery OR title:(mystery))',
     'kodi': frozenset({'mystery', 'film-noir', 'noir'})},
    {'label': 'Thriller', 'strict': '(subject:thriller OR genre:thriller)',
     'broad': '(title:(thriller))', 'kodi': frozenset({'thriller'})},
    {'label': 'Romance', 'strict': '(subject:romance OR genre:romance)',
     'broad': '(title:(romance OR love))', 'kodi': frozenset({'romance'})},
    {'label': 'Family', 'strict': '(subject:family OR genre:family)',
     'broad': '(title:(family))', 'kodi': frozenset({'family'})},
    {'label': 'Kids', 'strict': '(subject:children OR subject:kids OR genre:children)',
     'broad': '(title:(kids OR children))', 'kodi': frozenset({'children', 'kids', 'family'})},
    {'label': 'Animation / Cartoons',
     'strict': '(subject:animation OR subject:cartoons OR genre:animation)',
     'broad': '(title:(cartoon OR animation))', 'kodi': frozenset({'animation'})},
    {'label': 'Documentary', 'strict': '(subject:documentary OR genre:documentary)',
     'broad': '(title:(documentary))', 'kodi': frozenset({'documentary'})},
    {'label': 'History', 'strict': '(subject:history OR genre:history)',
     'broad': '(title:(history))', 'kodi': frozenset({'history'})},
    {'label': 'News', 'strict': '(subject:news OR genre:news)',
     'broad': '(title:(news OR newscast))', 'kodi': frozenset({'news'})},
    {'label': 'Sports', 'strict': '(subject:sports OR genre:sports)',
     'broad': '(title:(sports OR baseball OR football))', 'kodi': frozenset({'sport', 'sports'})},
    {'label': 'Music', 'strict': '(subject:music OR genre:music OR subject:musical)',
     'broad': '(title:(music OR musical))', 'kodi': frozenset({'music', 'musical'})},
    {'label': 'Reality', 'strict': '(subject:reality OR title:(reality))',
     'broad': '(description:(reality))', 'kodi': frozenset({'reality'})},
    {'label': 'Game Shows', 'strict': '(subject:game show OR title:("game show"))',
     'broad': '(description:("game show" OR quiz))', 'kodi': frozenset({'game show'})},
    {'label': 'Talk Shows', 'strict': '(subject:talk show OR title:("talk show"))',
     'broad': '(description:("talk show" OR interview))', 'kodi': frozenset({'talk show', 'talk'})},
    {'label': 'Variety', 'strict': '(subject:variety OR title:(variety))',
     'broad': '(description:(variety OR vaudeville))', 'kodi': frozenset({'variety'})},
    {'label': 'Lifestyle', 'strict': '(subject:lifestyle OR title:(lifestyle))',
     'broad': '(description:(lifestyle))', 'kodi': frozenset({'lifestyle'})},
    {'label': 'Food / Cooking', 'strict': '(subject:cooking OR subject:food OR title:(cooking))',
     'broad': '(description:(cooking OR recipe))', 'kodi': frozenset({'cooking', 'food'})},
    {'label': 'Travel', 'strict': '(subject:travel OR genre:travel OR title:(travel))',
     'broad': '(description:(travel))', 'kodi': frozenset({'travel'})},
    {'label': 'Nature', 'strict': '(subject:nature OR genre:nature OR title:(nature))',
     'broad': '(description:(nature OR wildlife))', 'kodi': frozenset({'nature'})},
    {'label': 'Science', 'strict': '(subject:science OR genre:science)',
     'broad': '(title:(science))', 'kodi': frozenset({'science'})},
    {'label': 'Technology', 'strict': '(subject:technology OR subject:computers OR title:(technology))',
     'broad': '(description:(technology OR computer))', 'kodi': frozenset({'technology'})},
    {'label': 'Educational', 'strict': '(subject:education OR subject:educational OR title:(educational))',
     'broad': '(description:(educational OR school))', 'kodi': frozenset({'educational', 'education'})},
    {'label': 'Religious / Faith', 'strict': '(subject:religion OR title:(church OR bible))',
     'broad': '(description:(religion OR church OR faith))', 'kodi': frozenset({'religion', 'religious'})},
    {'label': 'Westerns', 'strict': '(subject:western OR genre:western OR title:(western))',
     'broad': '(description:(western OR cowboy))', 'kodi': frozenset({'western'})},
    {'label': 'Classic TV', 'strict': '(subject:classic television OR title:("classic television"))',
     'broad': '(description:("classic television" OR vintage))', 'kodi': frozenset({'classic'})},
    {'label': 'Public Access', 'strict': '(subject:public access OR title:("public access"))',
     'broad': '(description:("public access" OR "community television"))', 'kodi': frozenset()},
    {'label': 'Local TV', 'strict': '(subject:local OR title:(local))',
     'broad': '(description:(local OR community))', 'kodi': frozenset()},
    {'label': 'Commercials / Advertising',
     'strict': '(subject:commercials OR subject:advertising OR title:(commercial))',
     'broad': '(description:(commercial OR advertisement))', 'kodi': frozenset()},
    {'label': 'Retro / Vintage Television',
     'strict': '(subject:vintage OR title:(vintage OR retro))',
     'broad': '(description:(vintage OR retro OR nostalgia))', 'kodi': frozenset()},
)


# Custom category locks: MAGIC lets the viewer type any phrase ("brazilian
# movies"). The lock label is stored as 'Custom: <phrase>' and its entry is
# built dynamically so search, surf and the menu share one definition.
CUSTOM_CATEGORY_PREFIX = 'Custom: '


def custom_category_phrase(label):
    """Free-text phrase from a custom lock label, or None when not custom."""
    if isinstance(label, str) and label.lower().startswith(CUSTOM_CATEGORY_PREFIX.lower()):
        phrase = label[len(CUSTOM_CATEGORY_PREFIX):].strip()
        if phrase:
            return phrase
    return None


def custom_category_clauses(phrase):
    # Unrestricted on purpose: no curated-collection gate, so both curated
    # collections AND individual uploads match. Strict tier first (exact
    # phrase in collection/subject/genre), then a broad word tier across
    # title, description and creator so sparse phrases still return results.
    clean = ' '.join(str(phrase).replace('"', ' ').split())
    if not clean:
        return []
    words = ' OR '.join(clean.split())
    return ['(collection:"{0}" OR subject:"{0}" OR genre:"{0}")'.format(clean),
            '(title:({0}) OR description:({0}) OR creator:({0}))'.format(words)]


def custom_result_score(document, phrase):
    # Rank custom matches so exact-phrase title hits outrank single-word
    # description hits: the broad OR tier returns volume, this puts the
    # most relevant first without dropping anything playable.
    words = title_words(phrase)
    clean = ' '.join(str(phrase).lower().split())
    fields = {}
    for key in ('title', 'subject', 'description', 'creator'):
        value = document.get(key) or ''
        if isinstance(value, list):
            value = ' '.join(str(item) for item in value)
        fields[key] = (str(value).lower(), title_words(value))
    score = 0
    if clean and clean in fields['title'][0]:
        score += 10
    for word in words:
        if word in fields['title'][1]:
            score += 3
        elif word in fields['subject'][1] or word in fields['creator'][1]:
            score += 2
        elif word in fields['description'][1]:
            score += 1
    return score


def web_search_url(query):
    # Opt-in escape hatch when the licensed sources come up empty: a plain
    # Google search opened on the viewer's phone, never scraped or played
    # by the addon itself.
    return 'https://www.google.com/search?q=' + urllib.parse.quote(query)


# Extra open providers. They run ONLY when a category lock is active --
# without a lock MAGIC searches the Internet Archive alone.
COMMONS_API = 'https://commons.wikimedia.org/w/api.php'
PEERTUBE_INSTANCES = ('https://peertube.tv',)
EXTERNAL_RESULT_LIMIT = 5


def commons_search(phrase, limit=EXTERNAL_RESULT_LIMIT):
    """Wikimedia Commons video files matching a phrase. Everything here is
    freely licensed; items carry a direct playable URL in _file_url (mp4
    preferred, webm accepted -- Kodi plays both) inside the Pi's size cap."""
    params = urllib.parse.urlencode({
        'action': 'query', 'format': 'json', 'generator': 'search',
        'gsrsearch': 'filetype:video {}'.format(phrase), 'gsrnamespace': 6,
        'gsrlimit': limit, 'prop': 'imageinfo',
        'iiprop': 'url|size|mime|extmetadata'})
    try:
        payload = web_json(COMMONS_API + '?' + params)
    except Exception as exc:
        xbmc.log('Retrovision Commons search: ' + repr(exc), xbmc.LOGWARNING)
        return []
    results = []
    pages = (payload.get('query', {}).get('pages') or {}).values()
    for page in pages:
        info = (page.get('imageinfo') or [{}])[0]
        mime = info.get('mime') or ''
        url = info.get('url') or ''
        try:
            size = int(info.get('size') or 0)
        except (TypeError, ValueError):
            size = 0
        if mime not in ('video/mp4', 'video/webm') or not url:
            continue
        if not 1024 * 1024 < size <= ARCHIVE_MAX_FILE_SIZE:
            continue
        meta = info.get('extmetadata') or {}
        license_name = (meta.get('LicenseShortName') or {}).get('value') or 'freely licensed'
        title = (page.get('title') or '').split(':', 1)[-1].rsplit('.', 1)[0].replace('_', ' ')
        results.append({'identifier': 'commons:{}'.format(page.get('pageid')),
                        'title': title or url,
                        'creator': 'Wikimedia Commons contributor',
                        'description': '',
                        '_license': '',
                        '_rights': 'Wikimedia Commons / {} -- verify on the file page'.format(license_name),
                        '_source': 'commons', '_file_url': url})
    return results[:limit]


def peertube_search(phrase, limit=EXTERNAL_RESULT_LIMIT):
    """Federated PeerTube videos matching a phrase, tried instance by
    instance. Only public, non-NSFW items with a direct playable file inside
    the Pi's size cap; the instance licence label rides along for the TV
    rights dialog."""
    results = []
    for base in PEERTUBE_INSTANCES:
        host = urllib.parse.urlsplit(base).netloc
        try:
            payload = web_json(base + '/api/v1/search/videos?' + urllib.parse.urlencode(
                {'search': phrase, 'count': limit, 'nsfw': 'false', 'sort': 'views'}))
        except Exception as exc:
            xbmc.log('Retrovision PeerTube search: ' + repr(exc), xbmc.LOGWARNING)
            continue
        for item in (payload.get('data') or [])[:limit]:
            if item.get('nsfw') or (item.get('privacy') or {}).get('id') != 1:
                continue
            uuid = item.get('uuid')
            if not uuid:
                continue
            try:
                detail = web_json(base + '/api/v1/videos/' + urllib.parse.quote(uuid))
            except Exception as exc:
                xbmc.log('Retrovision PeerTube details: ' + repr(exc), xbmc.LOGWARNING)
                continue
            choices = []
            for file_info in detail.get('files', []) or []:
                url = file_info.get('fileUrl') or ''
                try:
                    size = int(file_info.get('size') or 0)
                except (TypeError, ValueError):
                    size = 0
                if url and 1024 * 1024 < size <= ARCHIVE_MAX_FILE_SIZE:
                    choices.append((size, url))
            if not choices:
                continue
            choices.sort()
            licence = (item.get('licence') or {}).get('label') or 'unknown licence'
            account = item.get('account') or {}
            results.append({'identifier': 'peertube:{}'.format(uuid),
                            'title': item.get('name') or uuid,
                            'creator': account.get('displayName') or account.get('name') or host,
                            'description': item.get('truncatedDescription') or '',
                            '_license': '',
                            '_rights': 'PeerTube ({}) / {} -- verify before watching'.format(host, licence),
                            '_source': 'peertube', '_file_url': choices[0][1]})
        if results:
            break
    return results[:limit]


# Reddit Natural Search: 'reddit/{term}' in the custom category field
# resolves a term to the closest subreddit, then pulls video posts in the
# same result shape as the other providers.
REDDIT_SEARCH_API = 'https://www.reddit.com/subreddits/search.json'
REDDIT_CURATED_SUBREDDITS = ('OldCommercials', 'cartoons', 'ClassicCartoons',
                             'RetroGaming', '90sTV', 'dogs', 'dogvideos')


def reddit_category_query(phrase):
    """Search term after a 'reddit/' prefix, else None. Accepts a raw phrase
    or a 'Custom: ...' lock label."""
    label = custom_category_phrase(phrase) or phrase
    if not isinstance(label, str):
        return None
    text = label.strip()
    if text.lower().startswith('custom:'):
        text = text[len('custom:'):].strip()
    if not text[:7].lower() == 'reddit/':
        return None
    term = text[len('reddit/'):].strip()
    return term or None


def pick_best_subreddit(term, candidates):
    """Best subreddit name for a term. Exact name match first, then
    spaceless/underscore-insensitive match, then description keyword hits;
    subscriber count breaks ties. Falls back to r/{sanitized term}."""
    words = title_words(term)
    squashed = normalized(term)
    underscored = '_'.join(str(term).lower().split())

    def sub_score(candidate):
        name = str(candidate.get('display_name') or '')
        lowered = name.lower()
        score = 0
        if lowered == str(term).lower().strip():
            score += 100
        if normalized(name) == squashed or lowered == underscored:
            score += 60
        description = title_words(candidate.get('public_description') or '')
        score += 5 * len(words & description)
        try:
            score += min(float(candidate.get('subscribers') or 0) / 1000000.0, 5)
        except (TypeError, ValueError):
            pass
        return score

    best = None
    best_score = 0
    for candidate in candidates or []:
        name = candidate.get('display_name')
        if not name:
            continue
        score = sub_score(candidate)
        if score > best_score:
            best, best_score = str(name), score
    if best:
        return best
    fallback = ''.join(
        character for character in str(term).replace(' ', '').replace('_', '')
        if character.isalnum() or character in '-')
    return fallback or None


def search_subreddits(term, limit=10):
    """Raw subreddit search records for a term (empty list on failure)."""
    try:
        payload = web_json(REDDIT_SEARCH_API + '?' + urllib.parse.urlencode(
            {'q': term, 'limit': limit}))
    except Exception as exc:
        xbmc.log('Retrovision reddit search: ' + repr(exc), xbmc.LOGWARNING)
        return []
    return [child.get('data') or {}
            for child in (payload.get('data') or {}).get('children', [])]


def resolve_subreddit(term, search_fn=None):
    """Subreddit name for a reddit/ term: 'random' draws from the curated
    retro list, otherwise the best search hit, else the sanitized fallback."""
    if term is not None and term.strip().lower() == 'random':
        return random.choice(REDDIT_CURATED_SUBREDDITS)
    candidates = search_fn(term) if search_fn else search_subreddits(term)
    return pick_best_subreddit(term, candidates)


def get_reddit_videos(subreddit, limit=EXTERNAL_RESULT_LIMIT):
    """Video posts from a subreddit in the shared provider result shape.
    Text-only posts are skipped; each item carries a direct playable URL in
    _file_url."""
    try:
        payload = web_json('https://www.reddit.com/r/{}/hot.json?'.format(
            urllib.parse.quote(subreddit, safe='')) + urllib.parse.urlencode(
            {'limit': 25}))
    except Exception as exc:
        xbmc.log('Retrovision reddit videos: ' + repr(exc), xbmc.LOGWARNING)
        return []
    results = []
    for child in (payload.get('data') or {}).get('children', []):
        post = child.get('data') or {}
        url = ''
        reddit_video = (post.get('media') or {}).get('reddit_video') or {}
        if post.get('is_video') and reddit_video.get('fallback_url'):
            url = reddit_video['fallback_url'].split('?')[0]
        elif isinstance(post.get('url'), str) and post['url'].lower().endswith('.mp4'):
            url = post['url']
        if not url:
            continue
        description = first_text(post.get('selftext')) or ''
        results.append({'identifier': 'reddit:{}'.format(post.get('id')),
                        'title': first_text(post.get('title')) or url,
                        'creator': 'u/{} in r/{}'.format(
                            post.get('author') or 'unknown', subreddit),
                        'description': description[:500],
                        '_license': '',
                        '_rights': 'Reddit (r/{}) -- verify before watching'.format(subreddit),
                        '_source': 'reddit', '_file_url': url})
        if len(results) >= limit:
            break
    return results


def custom_result_matches(document, phrase):
    # Light relevance gate for custom searches: any phrase word (whole-word)
    # in the title, subject, description or creator. Far looser than the
    # every-word title_matches gate used for plain MAGIC searches.
    wanted = title_words(phrase)
    if not wanted:
        return False
    haystacks = []
    for key in ('title', 'subject', 'description', 'creator'):
        value = document.get(key) or ''
        if isinstance(value, list):
            value = ' '.join(str(item) for item in value)
        haystacks.append(title_words(value))
    combined = set().union(*haystacks) if haystacks else set()
    return bool(wanted & combined)


def category_lock_entry(label):
    # Table entry for a lock label (case-insensitive); custom 'Custom: ...'
    # labels build a dynamic entry. Unknown labels and
    # All resolve to the unrestricted first entry.
    for entry in CATEGORY_LOCKS:
        if entry['label'].lower() == (label or '').lower():
            return entry
    phrase = custom_category_phrase(label)
    if phrase:
        clauses = custom_category_clauses(phrase)
        return {'label': CUSTOM_CATEGORY_PREFIX + phrase,
                'strict': clauses[0] if len(clauses) > 0 else None,
                'broad': clauses[1] if len(clauses) > 1 else None,
                'kodi': frozenset(title_words(phrase))}
    return CATEGORY_LOCKS[0]


def category_lock_clauses(label):
    # Ordered Internet Archive clauses for a lock: strict first, then the
    # broad fallback. Empty when unlocked. Tiers keep sparse categories from
    # going silent without ever widening into unrelated categories.
    entry = category_lock_entry(label)
    return [clause for clause in (entry['strict'], entry['broad']) if clause]


def surf_genre_terms(genre):
    """All spellings of a surf genre accepted when matching a Kodi movie."""
    wanted = {genre.lower()}
    wanted |= {term.lower() for term in KODI_GENRE_TERMS.get(genre.lower(), ())}
    return wanted
# Reroll instead of stalling: the Zero 2 W over Wi-Fi cannot sustain bigger
# files, so oversized draws are skipped and another title is picked.
ARCHIVE_MAX_FILE_SIZE = 600 * 1024 * 1024
# Archive.org's advancedsearch rejects result windows past 10,000 hits with a
# [DEEP_PAGING] error payload (zero docs), so random surf pages must stay
# inside that window. With ARCHIVE_SURF_ROWS per page, pages run 1..199.
ARCHIVE_SURF_ROWS = 50
ARCHIVE_SURF_MAX_START = 10000
ARCHIVE_SURF_ATTEMPTS = 4


def save_json(path, data):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, indent=2))
    os.replace(temporary, path)


def current_item(channel, media, now):
    clips = [media[key] for key in channel.get('items', []) if key in media]
    if not clips:
        raise ValueError('Channel {!r} has no playable videos yet'.format(channel.get('name', channel.get('id'))))
    total = sum(clip['duration'] for clip in clips)
    if total <= 0:
        raise ValueError('Channel {!r} has no playable videos yet'.format(channel.get('name', channel.get('id'))))
    clock = now - EPOCH + channel.get('offset', 0)
    cycle = int(clock // total)
    position = clock % total
    for index, clip in enumerate(clips):
        if position < clip['duration']:
            return clip, position, (channel['id'], cycle, index)
        position -= clip['duration']
    return clips[0], 0, (channel['id'], cycle + 1, 0)


def json_rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if 'error' in response:
        raise RuntimeError(response['error'].get('message', 'Kodi library error'))
    return response.get('result', {})


def web_json(url, headers=None, timeout=12):
    request_headers = {'User-Agent': 'Retrovision/0.2 (Kodi)'}
    request_headers.update(headers or {})
    request = urllib.request.Request(url, headers=request_headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode('utf-8'))


def first_text(value):
    """First string when Archive.org hands back a list of titles (or an
    empty value): list titles crash every .lower() downstream."""
    if isinstance(value, list):
        value = value[0] if value else ''
    return value or ''


def normalized(value):
    value = unicodedata.normalize('NFKD', first_text(value)).encode('ascii', 'ignore').decode()
    return ''.join(character for character in value.lower() if character.isalnum())


def title_words(value):
    return set(''.join(character if character.isalnum() else ' ' for character in first_text(value).lower()).split())


def auto_play_license(license_url):
    """Licenses safe to play without a rights dialog: Public Domain Mark / CC0
    plus Creative Commons attribution licenses, which explicitly permit public
    playback. Anything else (a vague rights note, or nothing at all) still needs
    the on-TV confirmation."""
    url = license_url or ''
    if isinstance(url, list):
        url = url[0] if url else ''
    url = url.lower()
    return 'publicdomain' in url or 'creativecommons.org/licenses/' in url


def tuning_visible(mode, idle, tuning_until, playing, now):
    """Whether the out-of-sync static shows: every TV moment without video on
    screen -- the tune window, the idle wait, buffering (including a magic
    movie still loading), or stalled/ended playback -- never a black screen."""
    return mode == 'tv' and (idle or now < tuning_until or not playing)


def title_matches(title, phrase):
    # Whole-word match in both directions: every query word must appear as its own word
    # in the title. Plain substring-of-concatenated-string matching (e.g. via normalized())
    # falsely matches "cat" inside "vacation" or "arnold" inside "arnoldsville" -- this is
    # what was producing unrelated Archive results for short/common query words.
    query_words = title_words(phrase)
    return bool(query_words) and query_words <= title_words(title)


def random_archive_year():
    """One recency-weighted release year per reroll: older years are less
    likely, probability rising linearly up to 2026, so rerolls favor newer
    films while old ones still surface."""
    years = list(range(ARCHIVE_YEAR_MIN, ARCHIVE_YEAR_MAX + 1))
    weights = [year - ARCHIVE_YEAR_MIN + 1 for year in years]
    return random.choices(years, weights=weights, k=1)[0]


def archive_surf_query(year, genre=None):
    query = '{} AND year:{} AND NOT collection:tvnews'.format(ARCHIVE_SURF_ALL_QUERY, int(year))
    if genre:
        term = ARCHIVE_GENRE_TERMS.get(genre.lower(), genre)
        collection = ARCHIVE_GENRE_COLLECTIONS.get((genre or '').lower())
        if collection:
            query += ' AND (collection:"{}" OR subject:"{}" OR genre:"{}")'.format(collection, term, term)
        else:
            query += ' AND (subject:"{}" OR genre:"{}")'.format(term, term)
    return query


def item_year(document, fallback):
    """Best-effort 4-digit year from an Archive.org document for the on-TV label."""
    for key in ('year', 'date'):
        value = document.get(key)
        if isinstance(value, list):
            value = value[0] if value else ''
        digits = str(value or '')[:4]
        if len(digits) == 4 and digits.isdigit():
            return digits
    return str(fallback)


TV_NEWS_COLLECTIONS = {'tvnews'}
NEWS_TITLE_WORDS = {'news', 'newscast', 'newscasts'}


def is_news_item(document):
    """TV news never airs on RANDOM: the tvnews collection plus whole-word
    title matches (whole-word so 'Newsies' still plays)."""
    collections = document.get('collection') or []
    if isinstance(collections, str):
        collections = [collections]
    if any(str(name).lower() in TV_NEWS_COLLECTIONS for name in collections):
        return True
    return bool(title_words(document.get('title') or '') & NEWS_TITLE_WORDS)


class TVPlayer(xbmc.Player):
    def __init__(self, commands):
        super().__init__()
        self.commands = commands

    def onAVStarted(self):
        self.commands.put(('seek', None))

    def onPlayBackError(self):
        self.commands.put(('error', None))


class RemoteHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, status, payload, mime='application/json'):
        body = payload if isinstance(payload, bytes) else json.dumps(payload).encode()
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == '/':
            self.reply(200, (ROOT / 'remote.html').read_bytes(), 'text/html; charset=utf-8')
        elif self.path == '/api/state':
            self.reply(200, self.server.app.remote_state())
        elif self.path == '/api/addons':
            self.reply(200, {'files': self.server.app.addon_inbox_files()})
        else:
            self.reply(404, {'error': 'Not found'})

    def do_POST(self):
        if not hmac.compare_digest(self.headers.get('X-Retro-Pin', ''), self.server.app.pin):
            self.reply(403, {'error': 'Enter the pairing code shown on the TV.'})
            return
        try:
            length = int(self.headers.get('Content-Length', 0))
            if self.path == '/api/addons/upload':
                if not 0 < length <= 100 * 1024 * 1024:
                    raise ValueError('Add-on ZIP must be smaller than 100 MB')
                filename = Path(urllib.parse.unquote(self.headers.get('X-Filename', ''))).name
                if not filename.lower().endswith('.zip') or len(filename) > 160:
                    raise ValueError('Choose a Kodi add-on ZIP file')
                destination = ADDON_INBOX / filename
                temporary = destination.with_suffix(destination.suffix + '.uploading')
                with temporary.open('wb') as output:
                    remaining = length
                    while remaining:
                        block = self.rfile.read(min(1024 * 1024, remaining))
                        if not block:
                            raise ValueError('Upload ended early')
                        output.write(block)
                        remaining -= len(block)
                if not zipfile.is_zipfile(temporary):
                    temporary.unlink(missing_ok=True)
                    raise ValueError('That file is not a valid ZIP')
                os.replace(temporary, destination)
                self.reply(200, {'ok': True, 'file': filename})
                return
            if not 0 < length <= 8192:
                raise ValueError('Invalid request size')
            data = json.loads(self.rfile.read(length))
            if self.path == '/api/control':
                command = data.get('command')
                if command not in ('next', 'prev', 'tv', 'home', 'guide', 'channel', 'banner', 'volumeup', 'volumedown', 'mute', 'controls', 'playpause', 'magic', 'installaddons'):
                    raise ValueError('Unknown command')
                value = data.get('value')
                if command == 'channel':
                    value = int(value)
                    if value not in [c['id'] for c in self.server.app.config['channels']]:
                        raise ValueError('Unknown channel')
                self.server.app.commands.put((command, value))
            elif self.path == '/api/channels':
                channels = data['channels']
                if not isinstance(channels, list) or not 1 <= len(channels) <= 12:
                    raise ValueError('Choose between 1 and 12 channels')
                clean = []
                for number, channel in enumerate(channels, 1):
                    name = str(channel['name']).strip()
                    items = channel['items']
                    if not name or len(name) > 30 or any(ord(c) < 32 or c in '[]' for c in name):
                        raise ValueError('Channel names must be 1–30 plain characters')
                    if not isinstance(items, list) or not 1 <= len(items) <= 100:
                        raise ValueError('Each channel needs videos')
                    if any(key not in self.server.app.config['media'] for key in items):
                        raise ValueError('Choose videos from the library')
                    clean.append({'id': number, 'name': name, 'items': items, 'offset': (number - 1) * 21})
                self.server.app.commands.put(('save', clean))
            else:
                self.reply(404, {'error': 'Not found'})
                return
            self.reply(200, {'ok': True})
        except (ValueError, KeyError, TypeError) as exc:
            self.reply(400, {'error': str(exc)})


class RetroTV(xbmcgui.WindowXMLDialog):
    def __init__(self, *args):
        super().__init__(*args)
        self.config = json.loads(CONFIG.read_text())
        self.commands = queue.Queue()
        self.player = TVPlayer(self.commands)
        self.monitor = xbmc.Monitor()
        self.closed = threading.Event()
        self.mode = 'home'
        self.channel = 0
        self.paused_at = None
        self.clock_delay = 0
        self.magic_active = False
        self.magic_show = None
        self.magic_episodes = []
        self.magic_local = {}
        self.magic_availability = {}
        self.magic_playlist = []
        self.magic_index = -1
        self.web_fallback = None
        self.surf_active = False
        self.surf_idle = False
        self.pending_surf = False
        self.pick_running = False
        self.surf_genre = None
        self.surf_genre_order = random.sample(list(SURF_GENRES), len(SURF_GENRES))
        self.surf_genre_index = 0
        self.archive_collection_sizes = {}
        self.recent_archive_ids = []
        self.recent_library_files = []
        self.pluto_catalog = None
        self.provider_lock = threading.Lock()
        self.lock_path = DATA / 'category-lock.json'
        try:
            saved = json.loads(self.lock_path.read_text()).get('label', '')
            entry = category_lock_entry(saved)
            self.category_lock = '' if entry is CATEGORY_LOCKS[0] else entry['label']
        except (OSError, ValueError, AttributeError, TypeError):
            self.category_lock = ''
        self.state_path = DATA / 'last-channel.json'
        try:
            last_id = json.loads(self.state_path.read_text())['channel']
            self.channel = next((i for i,c in enumerate(self.config['channels']) if c['id'] == last_id), 0)
        except (OSError, ValueError, KeyError, TypeError):
            pass
        self.key = None
        self.banner_until = 0
        self.tuning_until = 0
        self.tuning_duration = 0.55
        self.server = None
        self.last_caption = ''
        pinfile = DATA / 'pairing-code'
        if not pinfile.exists():
            pinfile.write_text(str(secrets.randbelow(900000) + 100000))
            os.chmod(pinfile, 0o600)
        self.pin = pinfile.read_text().strip()
        self.ip = xbmc.getIPAddress()
        self.remote_url = 'http://{}:8097'.format(self.ip)

    def onInit(self):
        self.surf_idle = False
        self.setProperty('retro.mode', 'home')
        self.setFocusId(100)
        self.setProperty('retro.playlabel', 'PAUSE')
        self.ensure_addon_source()
        try:
            self.server = ThreadingHTTPServer(('0.0.0.0', 8097), RemoteHandler)
            self.server.daemon_threads = True
            self.server.app = self
            threading.Thread(target=self.server.serve_forever, daemon=True).start()
        except OSError as exc:
            self.remote_url = 'Remote unavailable: ' + str(exc)
        self.worker = threading.Thread(target=self.tick, daemon=True)
        self.worker.start()
        threading.Thread(target=self.load_pluto_catalog, daemon=True).start()
        # Launch straight into the out-of-sync dial waiting for a CH press --
        # never a black screen, never an autoplayed broadcast.
        self.enter_surf_idle()

    def onClick(self, control):
        command = {100:'tv',101:'exit',102:'about',200:'prev',201:'guide',202:'next',203:'home',205:'magic',210:'banner',204:'controls',220:'volumedown',221:'volumeup',222:'playpause',223:'mute'}.get(control)
        if command:
            self.commands.put((command, None))

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (9, 10, 92):
            self.commands.put(('home' if self.mode == 'tv' else 'exit', None))
        elif self.mode == 'tv' and action_id in (3, 5, 184):
            self.commands.put(('next', None))
        elif self.mode == 'tv' and action_id in (4, 6, 185):
            self.commands.put(('prev', None))
        elif self.mode == 'tv' and action_id == 11:
            self.commands.put(('guide', None))

    def remote_state(self):
        now = time.time()
        if not self.config.get('channels'):
            return {'mode': self.mode, 'channel': None, 'channels': [],
                    'media': {key: clip['title'] for key, clip in self.config.get('media', {}).items()},
                    'lock': getattr(self, 'category_lock', ''),
                    'web_search': getattr(self, 'web_fallback', None)}
        channels = []
        for c in self.config['channels']:
            clip, elapsed, key = current_item(c, self.config['media'], self.channel_time() if c['id'] == self.config['channels'][self.channel]['id'] and self.mode == 'tv' else now)
            channels.append({'id':c['id'],'name':c['name'],'items':c['items'],'now':clip['title'],'remaining':max(0,int(clip['duration']-elapsed))})
        return {'mode':self.mode, 'channel':self.config['channels'][self.channel]['id'], 'channels':channels,
                'media':{key:clip['title'] for key,clip in self.config['media'].items()},
                'lock':getattr(self, 'category_lock', ''),
                'web_search':getattr(self, 'web_fallback', None)}

    def show_banner(self):
        self.banner_until = time.monotonic() + 5
        self.setProperty('retro.banner', 'yes')

    def magic_lock_label(self):
        return 'CATEGORY LOCK: ' + (self.category_lock.upper() if self.category_lock else 'OFF')

    def set_category_lock(self, label):
        entry = category_lock_entry(label)
        self.category_lock = '' if entry is CATEGORY_LOCKS[0] else entry['label']
        try:
            save_json(self.lock_path, {'label': self.category_lock})
        except OSError as exc:
            xbmc.log('Retrovision category lock kept session-only: ' + repr(exc), xbmc.LOGWARNING)
        xbmc.log('Retrovision category lock: ' + (self.category_lock or 'OFF'), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('MAGIC',
            'Category lock: {}'.format(self.category_lock or 'OFF (all categories)'),
            xbmcgui.NOTIFICATION_INFO, 4000)

    def choose_category_lock(self):
        # MAGIC category selector. Returns True when the lock changed. The
        # last row prompts for a free-text custom category ("brazilian
        # movies") searched across collections and individual uploads.
        rows = []
        for entry in CATEGORY_LOCKS:
            active = bool(self.category_lock) and entry['label'] == self.category_lock
            rows.append(('* ' if active else '  ') + entry['label'].upper())
        custom_active = bool(custom_category_phrase(self.category_lock))
        rows.append(('* ' if custom_active else '  ') + 'CUSTOM... / TYPE YOUR OWN')
        selected = xbmcgui.Dialog().select('MAGIC / CATEGORY LOCK', rows)
        if selected < 0:
            return False
        before = self.category_lock
        if selected == len(rows) - 1:
            keyboard = xbmc.Keyboard('', 'MAGIC / TYPE A CUSTOM CATEGORY')
            keyboard.doModal()
            if not keyboard.isConfirmed() or not keyboard.getText().strip():
                return False
            self.set_category_lock(CUSTOM_CATEGORY_PREFIX + keyboard.getText().strip())
            return self.category_lock != before
        self.set_category_lock(CATEGORY_LOCKS[selected]['label'])
        return self.category_lock != before

    def channel_time(self):
        return (self.paused_at if self.paused_at is not None else time.time()) - self.clock_delay

    def tune(self, index):
        self.magic_active = False
        self.magic_playlist = []
        self.magic_index = -1
        self.surf_active = False
        self.pending_surf = False
        self.paused_at = None
        self.clock_delay = 0
        self.setProperty("retro.playlabel", "PAUSE")
        if not self.config.get('channels'):
            xbmcgui.Dialog().notification('Retrovision', 'No channels yet. Add videos to the library first.',
                                           xbmcgui.NOTIFICATION_INFO, 5000)
            return
        self.channel = index % len(self.config['channels'])
        save_json(self.state_path, {"channel": self.config["channels"][self.channel]["id"]})
        self.mode = 'tv'
        self.key = None
        self.setProperty('retro.mode', 'tv')
        # Focus the video area, not GUIDE: after a CH press the next OK must
        # not open the channel guide.
        self.setFocusId(210)
        self.setProperty('retro.tuning', 'yes')
        self.tuning_until = time.monotonic() + self.tuning_duration
        self.show_banner()

    def play_scheduled(self):
        if not self.config.get('channels'):
            return
        channel = self.config['channels'][self.channel]
        clip, elapsed, key = current_item(channel, self.config['media'], self.channel_time())
        if key != self.key:
            path = Path(clip['path'])
            if not path.is_file():
                raise RuntimeError('Missing video: '+str(path))
            self.key = key
            item = xbmcgui.ListItem(label=clip['title'], path=str(path))
            item.setInfo('video', {'title':clip['title'], 'duration':int(clip['duration'])})
            item.setProperty('IsPlayable', 'true')
            self.player.play(str(path), item, windowed=True)
            self.show_banner()
        self.setProperty('retro.channel', '{:02d}  {}'.format(channel['id'], channel['name'].upper()))
        self.setProperty('retro.program', clip['title'])
        remaining = max(0, int(clip['duration'] - elapsed))
        caption = 'ON AIR  /  {:02d}:{:02d} REMAINING'.format(remaining//60,remaining%60)
        if caption != self.last_caption:
            self.setProperty('retro.remaining', caption)
            self.last_caption = caption

    def local_show_episodes(self, show):
        shows = json_rpc('VideoLibrary.GetTVShows', {
            'properties': ['title', 'originaltitle', 'year'],
            'limits': {'start': 0, 'end': 5000}
        }).get('tvshows', [])
        names = {normalized(show.get('name')), normalized(show.get('_query'))}
        match = next((item for item in shows if normalized(item.get('title')) in names or
                      normalized(item.get('originaltitle')) in names), None)
        if not match:
            return {}
        episodes = json_rpc('VideoLibrary.GetEpisodes', {
            'tvshowid': match['tvshowid'],
            'properties': ['title', 'season', 'episode', 'file', 'playcount'],
            'limits': {'start': 0, 'end': 10000},
            'sort': {'method': 'episode', 'order': 'ascending'}
        }).get('episodes', [])
        found = {(item.get('season'), item.get('episode')): item for item in episodes if item.get('file')}
        for item in found.values():
            item['_source'] = 'KODI LIBRARY'
        return found

    def enter_surf_idle(self):
        """Launch/waiting state: out-of-sync static with the dial waiting for a
        CH press. No video plays and no roll happens until next/prev arrives."""
        self.surf_active = False
        self.surf_idle = True
        self.pending_surf = False
        self.magic_active = False
        self.magic_playlist = []
        self.magic_index = -1
        self.mode = 'tv'
        self.setProperty('retro.mode', 'tv')
        self.setFocusId(210)
        self.setProperty('retro.tuning', 'yes')
        # Long-but-finite timers: the idle dial waits ~24h for a CH press.
        # float('inf') must not be used here -- the tick loop's roll/jitter
        # math calls int() on values derived from tuning_until, and
        # int(inf) raises "cannot convert float infinity to integer".
        self.tuning_until = time.monotonic() + 86400
        self.setProperty('retro.channel', 'RANDOM')
        self.setProperty('retro.program', 'OUT OF SYNC / PRESS CH + OR CH - TO ROLL THE DICE')
        self.setProperty('retro.remaining', 'MOVIES ONLY / EVERY YEAR 1900-2026 EQUALLY LIKELY')
        self.banner_until = time.monotonic() + 86400
        self.setProperty('retro.banner', 'yes')

    def next_surf_genre(self):
        """Next category in this session's shuffled rotation: always another
        genre than the last roll, cycling through every category."""
        if not getattr(self, 'surf_genre_order', None):
            self.surf_genre_order = random.sample(list(SURF_GENRES), len(SURF_GENRES))
            self.surf_genre_index = 0
        genre = self.surf_genre_order[self.surf_genre_index % len(self.surf_genre_order)]
        self.surf_genre_index += 1
        if self.surf_genre_index % len(self.surf_genre_order) == 0:
            self.surf_genre_order = random.sample(list(SURF_GENRES), len(SURF_GENRES))
        return genre

    def enter_surf_mode(self):
        """A fresh random movie in a new genre category -- from your own
        library or an Internet Archive film from a recency-weighted year
        rising to 2026 -- every time CH is pressed. Starts with the
        out-of-sync static, then rolls the pick as the dial settles."""
        self.surf_active = True
        self.magic_active = False
        self.magic_playlist = []
        self.magic_index = -1
        self.paused_at = None
        self.clock_delay = 0
        self.key = None
        self.mode = 'tv'
        self.setProperty('retro.mode', 'tv')
        # Video area keeps focus so OK never lands on GUIDE after a reroll.
        self.setFocusId(210)
        self.setProperty('retro.tuning', 'yes')
        self.tuning_until = time.monotonic() + self.tuning_duration
        self.surf_idle = False
        if self.category_lock:
            self.surf_genre = self.category_lock
        else:
            self.surf_genre = self.next_surf_genre()
        self.setProperty('retro.channel', 'RANDOM  /  ' + self.surf_genre.upper())
        self.setProperty('retro.program', 'TUNING TO {}...'.format(self.surf_genre.upper()))
        self.setProperty('retro.remaining', 'HOLD ON / ROLLING THE DICE')
        self.pending_surf = True
        self.banner_until = time.monotonic() + 30
        self.setProperty('retro.banner', 'yes')

    def play_random_library_movie(self, genre=None):
        """RANDOM source: movies in your own Kodi library. Prefers the rolled
        genre category, falling back to any movie when nothing matches, so a
        thinly-tagged library never stalls the reroll. Returns False if
        nothing playable turned up, so play_random_pick can try another source
        instead."""
        movies = json_rpc('VideoLibrary.GetMovies', {
            'properties': ['title', 'year', 'genre', 'file'], 'limits': {'start': 0, 'end': 5000}
        }).get('movies', [])
        # Skip .strm pointers: the library holds the Retrovision launcher shim,
        # which would re-enter the app instead of playing a film.
        found = [item for item in movies if item.get('file') and not item['file'].lower().endswith('.strm')]
        if not found:
            return False
        lock = getattr(self, 'category_lock', '')
        if lock:
            wanted = category_lock_entry(lock)['kodi']
            if not wanted:
                return False
            found = [item for item in found
                     if wanted & {str(name).lower() for name in (item.get('genre') or [])}]
            if not found:
                return False
        elif genre:
            wanted = surf_genre_terms(genre)
            matching = [item for item in found
                        if wanted & {str(name).lower() for name in (item.get('genre') or [])}]
            if matching:
                found = matching
        fresh = [item for item in found if item.get('file') not in self.recent_library_files]
        movie = random.choice(fresh or found)
        self.recent_library_files.append(movie['file'])
        self.recent_library_files = self.recent_library_files[-20:]
        self.paused_at = None
        self.clock_delay = 0
        self.key = None
        self.setProperty('retro.playlabel', 'PAUSE')
        title = movie.get('title') or 'Movie'
        item = xbmcgui.ListItem(label=title, path=movie['file'])
        info = {'title': title}
        if movie.get('year'):
            info['year'] = movie['year']
        item.setInfo('video', info)
        item.setProperty('IsPlayable', 'true')
        self.player.play(movie['file'], item, windowed=True)
        genre_label = '  /  ' + genre.upper() if genre else ''
        self.setProperty('retro.channel', 'RANDOM  /  YOUR MOVIES' + genre_label)
        self.setProperty('retro.program', title if not movie.get('year') else '{} ({})'.format(title, movie['year']))
        self.setProperty('retro.remaining', 'KODI LIBRARY  /  CH +/- KEEPS SURFING')
        self.show_banner()
        return True

    def archive_query_size(self, query):
        cached = self.archive_collection_sizes.get(query)
        if cached is not None:
            return cached
        try:
            total = web_json('https://archive.org/advancedsearch.php?' + urllib.parse.urlencode({
                'q': query, 'rows': 0, 'output': 'json'
            })).get('response', {}).get('numFound', 0)
        except Exception as exc:
            xbmc.log('Retrovision RANDOM archive count: ' + repr(exc), xbmc.LOGWARNING)
            # A failed count must not poison the cache: returning 0 without
            # storing it lets the next CH press retry the network instead of
            # failing instantly for the rest of the session.
            return 0
        self.archive_collection_sizes[query] = total
        return total

    def random_archive_item_broad(self, genre=None, clauses=None, unrestricted=False):
        """Recency-weighted RANDOM sampling: every reroll first draws a year
        (older years less likely, rising to 2026), then samples a movie within
        that year and the rolled genre. Falls back to the year alone when the
        genre has nothing countable, so the reroll never stalls -- except with
        a category lock (clauses): only the lock tiers are tried, strict
        first, and an empty lock reads as nothing playable, never widening.
        With unrestricted (custom categories), the curated-collection gate
        and the confidence filter are dropped so any video can surface.
        Returns the
        raw document with _license/_rights/_year attached and NO rights
        filtering -- RANDOM plays the pick directly."""
        query = None
        total = 0
        year = None
        base = ARCHIVE_CUSTOM_SURF_BASE if unrestricted else ARCHIVE_SURF_ALL_QUERY
        for _ in range(ARCHIVE_SURF_YEAR_ATTEMPTS):
            year = random_archive_year()
            if clauses:
                for clause in clauses:
                    query = '{} AND year:{} AND NOT collection:tvnews AND ({})'.format(
                        base, int(year), clause)
                    total = self.archive_query_size(query)
                    if total:
                        break
                if total:
                    break
                continue
            if genre:
                query = archive_surf_query(year, genre)
                total = self.archive_query_size(query)
                if total:
                    break
                query = archive_surf_query(year)
                total = self.archive_query_size(query)
                if total:
                    break
                continue
            query = archive_surf_query(year)
            total = self.archive_query_size(query)
            if total:
                break
        if not total:
            return None
        rows = ARCHIVE_SURF_ROWS
        # Pages stay inside archive.org's 10,000-hit deep-paging window: deeper
        # pages come back as an error payload with zero docs ("nothing playable").
        max_page = max(1, min((ARCHIVE_SURF_MAX_START - rows) // rows, -(-total // rows)))
        # Vary the sort so rerolls within a big year are not stuck on one slice.
        sort = random.choices(['date desc', 'downloads desc', ''], weights=[3, 1, 1], k=1)[0]
        params = {'q': query,
                  'fl[]': 'identifier,title,licenseurl,rights,creator,date,year,collection',
                  'rows': rows, 'page': random.randint(1, max_page), 'output': 'json'}
        if sort:
            params['sort[]'] = sort
        try:
            data = web_json('https://archive.org/advancedsearch.php?' + urllib.parse.urlencode(params))
        except Exception as exc:
            xbmc.log('Retrovision RANDOM broad archive search: ' + repr(exc), xbmc.LOGWARNING)
            return None
        if data.get('error'):
            xbmc.log('Retrovision RANDOM broad archive search: ' + str(data['error'])[:200], xbmc.LOGWARNING)
            return None
        documents = data.get('response', {}).get('docs', [])
        pool = []
        for document in documents:
            if not document.get('identifier'):
                continue
            document['title'] = first_text(document.get('title')) or document.get('identifier') or 'Untitled'
            confidence = 1 if unrestricted else archive_confidence(document)
            if not confidence:
                continue
            license_url = document.get('licenseurl') or ''
            if isinstance(license_url, list):
                license_url = license_url[0] if license_url else ''
            document['_license'] = license_url
            document['_rights'] = document.get('rights') or ''
            document['_year'] = item_year(document, year)
            document['_confidence'] = confidence
            document['_unrestricted'] = unrestricted
            pool.append(document)
        if not pool:
            return None
        if not unrestricted:
            # Prefer the most confident tier (clean film titles in trusted
            # collections); fall back to lower tiers so the reroll never stalls.
            top = max(document['_confidence'] for document in pool)
            pool = [document for document in pool if document['_confidence'] == top]
        fresh = [document for document in pool if document['identifier'] not in self.recent_archive_ids]
        choice = random.choice(fresh or pool)
        self.recent_archive_ids.append(choice['identifier'])
        self.recent_archive_ids = self.recent_archive_ids[-20:]
        return choice

    def play_random_archive_item(self, item):
        video_url = self.archive_video_url(item['identifier'],
                                           allow_short=bool(item.get('_unrestricted')))
        if not video_url:
            return False
        title = item.get('title') or item.get('identifier') or 'Untitled'
        license_url = item.get('_license', item.get('licenseurl'))
        if isinstance(license_url, list):
            license_url = license_url[0] if license_url else ''
        license_url = license_url or ''
        creator = item.get('creator') or 'Unknown uploader/creator'
        if isinstance(creator, list):
            creator = ', '.join(str(value) for value in creator)
        is_public_domain = 'publicdomain' in license_url.lower()
        self.paused_at = None
        self.clock_delay = 0
        self.key = None
        self.setProperty('retro.playlabel', 'PAUSE')
        listitem = xbmcgui.ListItem(label=title, path=video_url)
        listitem.setInfo('video', {'title': title})
        listitem.setProperty('IsPlayable', 'true')
        self.player.play(video_url, listitem, windowed=True)
        surf_genre = getattr(self, 'surf_genre', None)
        genre_label = '  /  ' + surf_genre.upper() if surf_genre else ''
        self.setProperty('retro.channel', 'RANDOM  /  INTERNET ARCHIVE' + genre_label)
        year_label = item.get('_year') or ''
        self.setProperty('retro.program', title if not year_label else '{} ({})'.format(title, year_label))
        self.setProperty('retro.remaining', 'INTERNET ARCHIVE  /  CH +/- KEEPS SURFING')
        self.show_banner()
        if auto_play_license(license_url) and not is_public_domain:
            # CC-licensed pick auto-played with no dialog: surface the
            # creator/license so the attribution term stays visible.
            xbmcgui.Dialog().notification('RANDOM', '{} / Creative Commons / {}'.format(title, creator),
                                           xbmcgui.NOTIFICATION_INFO, 5000)
        return True

    def play_random_pick(self, genre=None):
        """RANDOM's actual reroll: movies only -- your Kodi movies and an
        Internet Archive movie drawn from a recency-weighted year rising to
        2026, both filtered to the rolled genre category. Sources are tried in
        a random order on every reroll. TV broadcasts and episodes are never
        chosen."""
        lock = getattr(self, 'category_lock', '')
        clauses = category_lock_clauses(lock) if lock else None
        unrestricted = bool(custom_category_phrase(lock))
        genre = None if clauses else (genre if genre is not None else getattr(self, 'surf_genre', None))
        order = ['movie', 'archive']
        random.shuffle(order)
        for source in order:
            if source == 'archive':
                # Several fresh draws: a single flaky search or an item with no
                # Pi-compatible file must not end the whole reroll.
                for _ in range(ARCHIVE_SURF_ATTEMPTS):
                    item = self.random_archive_item_broad(genre, clauses, unrestricted)
                    if item and self.play_random_archive_item(item):
                        return
            elif self.play_random_library_movie(genre):
                return
        if lock:
            xbmcgui.Dialog().notification('RANDOM', 'Nothing playable turned up for {}. Try another category.'.format(lock),
                                           xbmcgui.NOTIFICATION_INFO, 6000)
        else:
            xbmcgui.Dialog().notification('RANDOM', 'Nothing playable turned up this time. Press CH to try again.',
                                           xbmcgui.NOTIFICATION_INFO, 5000)
        self.surf_active = False

    def addon_zip_details(self, archive):
        try:
            with zipfile.ZipFile(archive) as package:
                entries = package.infolist()
                if not entries or len(entries) > 5000:
                    raise ValueError('invalid file count')
                if sum(entry.file_size for entry in entries) > 500 * 1024 * 1024:
                    raise ValueError('expanded size exceeds 500 MB')
                roots = set()
                for entry in entries:
                    clean = entry.filename.replace('\\', '/')
                    parts = [part for part in clean.split('/') if part]
                    if not parts or clean.startswith('/') or '..' in parts:
                        raise ValueError('unsafe path in ZIP')
                    if ((entry.external_attr >> 16) & 0o170000) == 0o120000:
                        raise ValueError('symbolic links are not accepted')
                    roots.add(parts[0])
                if len(roots) != 1:
                    raise ValueError('ZIP must contain one add-on folder')
                root = next(iter(roots))
                try:
                    manifest = ET.fromstring(package.read(root + '/addon.xml'))
                except KeyError:
                    raise ValueError('addon.xml is missing')
                addon_id = (manifest.get('id') or '').strip()
                if not addon_id or any(character not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-' for character in addon_id):
                    raise ValueError('addon.xml has an invalid id')
                return {'file': archive.name, 'size': archive.stat().st_size, 'id': addon_id,
                        'name': manifest.get('name') or addon_id,
                        'version': manifest.get('version') or 'unknown', 'valid': True}
        except Exception as exc:
            return {'file': archive.name, 'size': archive.stat().st_size, 'valid': False, 'error': str(exc)}

    def addon_inbox_files(self):
        return [self.addon_zip_details(path) for path in sorted(ADDON_INBOX.glob('*.zip')) if path.is_file()]

    def ensure_addon_source(self):
        sources_path = Path(xbmcvfs.translatePath('special://profile/sources.xml'))
        try:
            tree = ET.parse(sources_path)
            root = tree.getroot()
        except (OSError, ET.ParseError):
            root = ET.Element('sources')
            tree = ET.ElementTree(root)
        files = root.find('files')
        if files is None:
            files = ET.SubElement(root, 'files')
            ET.SubElement(files, 'default', {'pathversion': '1'})
        for source in files.findall('source'):
            if source.findtext('name') == 'Retrovision Add-on Inbox':
                return
        source = ET.SubElement(files, 'source')
        ET.SubElement(source, 'name').text = 'Retrovision Add-on Inbox'
        ET.SubElement(source, 'path', {'pathversion': '1'}).text = str(ADDON_INBOX) + '/'
        ET.SubElement(source, 'allowsharing').text = 'true'
        temporary = sources_path.with_suffix('.tmp')
        tree.write(temporary, encoding='utf-8', xml_declaration=True)
        os.replace(temporary, sources_path)

    def install_addons_from_inbox(self):
        packages = self.addon_inbox_files()
        if not packages:
            xbmcgui.Dialog().textviewer('MAGIC / ADD-ON INBOX',
                'The inbox is empty.\n\nOn your phone, open {} and choose ADD-ON INBOX. You can upload several Kodi ZIP files at once.'.format(self.remote_url))
            return
        rows = []
        for package in packages:
            if package.get('valid'):
                rows.append('{}  v{}  /  {}'.format(package['name'], package['version'], package['file']))
            else:
                rows.append('INVALID ZIP  /  {}  /  {}'.format(package['file'], package.get('error', 'Unknown error')))
        selected = xbmcgui.Dialog().select('MAGIC / ADD-ON INBOX', rows)
        if selected < 0:
            return
        package = packages[selected]
        if not package.get('valid'):
            xbmcgui.Dialog().textviewer('MAGIC / INVALID ADD-ON ZIP', package.get('error', 'This ZIP cannot be installed.'))
            return
        if xbmcgui.Dialog().yesno('MAGIC / OPEN KODI INSTALLER',
                '{} v{}\n\nZIP: {}\n\nChoose “Retrovision Add-on Inbox” in Kodi, then choose this ZIP.'.format(
                    package['name'], package['version'], package['file']),
                yeslabel='OPEN INSTALLER', nolabel='CANCEL'):
            xbmc.executebuiltin('InstallFromZip')

    def pluto_url(self, path):
        joiner = '&' if '?' in path else '?'
        return 'https://api.pluto.tv{}{}deviceType=web&sid={}&deviceId={}'.format(
            path, joiner, secrets.token_hex(16), secrets.token_hex(16))

    def pluto_json(self, path, timeout_label='Pluto TV'):
        return web_json(self.pluto_url(path), {
            'Accept': 'application/json',
            'Origin': 'http://pluto.tv',
            'Referer': 'http://pluto.tv/',
            'User-Agent': 'Mozilla/5.0'
        }, timeout=60)

    def load_pluto_catalog(self):
        with self.provider_lock:
            if self.pluto_catalog is not None:
                return self.pluto_catalog
            try:
                fresh = PLUTO_CACHE.exists() and time.time() - PLUTO_CACHE.stat().st_mtime < 21600
                if fresh:
                    self.pluto_catalog = json.loads(PLUTO_CACHE.read_text())
                    return self.pluto_catalog
                data = self.pluto_json('/v3/vod/categories?offset=1000&includeItems=true&')
                catalog = {}
                for category in data.get('categories', []):
                    for item in category.get('items', []):
                        if item.get('_id') and item.get('name') and item.get('type') in ('series', 'movie', 'film'):
                            catalog[item['_id']] = {
                                'id': item['_id'], 'name': item['name'], 'type': item.get('type'),
                                'description': item.get('description') or item.get('summary') or ''
                            }
                self.pluto_catalog = list(catalog.values())
                save_json(PLUTO_CACHE, self.pluto_catalog)
            except Exception as exc:
                xbmc.log('Retrovision Pluto catalog: ' + repr(exc), xbmc.LOGWARNING)
                self.pluto_catalog = []
            return self.pluto_catalog

    def pluto_show(self, show):
        target = normalized(show.get('name'))
        catalog = self.load_pluto_catalog()
        exact = [item for item in catalog if normalized(item.get('name')) == target and item.get('type') == 'series']
        return exact[0] if exact else None

    def pluto_episodes(self, show):
        data = self.pluto_json('/v3/vod/series/{}/seasons?includeItems=true&'.format(show['id']))
        episodes = []
        available = {}
        for season in data.get('seasons', []):
            for episode in season.get('episodes', []):
                number = episode.get('number')
                season_number = episode.get('season', season.get('number'))
                if number is None or season_number is None or not episode.get('_id'):
                    continue
                title = episode.get('name') or 'Episode {}'.format(number)
                episodes.append({'season': season_number, 'number': number, 'name': title})
                available[(season_number, number)] = {
                    'title': title, 'season': season_number, 'episode': number,
                    '_source': 'PLUTO TV / OFFICIAL APP REQUIRED'
                }
        return episodes, available

    def archive_search(self, query):
        phrase = ''.join(character if character.isalnum() or character in ' -_' else ' ' for character in query).strip()
        if not phrase:
            return []
        base = '(title:"{0}" OR subject:"{0}") AND mediatype:movies'.format(phrase)
        lock = getattr(self, 'category_lock', '')
        custom = custom_category_phrase(lock)
        reddit_term = reddit_category_query(custom or '')
        if reddit_term is not None:
            subreddit = resolve_subreddit(reddit_term)
            if subreddit:
                return get_reddit_videos(subreddit, limit=20)
            return []
        if custom:
            # Custom category: unrestricted search over collections and
            # individual uploads (no curated-collection gate), newest or most
            # downloaded first. Rights are still confirmed per item before play.
            searches = ['{} AND mediatype:movies'.format(clause)
                        for clause in custom_category_clauses(custom)]
        else:
            tiers = category_lock_clauses(lock) if lock else []
            searches = [base + ' AND (' + clause + ')' for clause in tiers] or [base]
        xbmc.log('Retrovision MAGIC search (lock={}): {}'.format(lock or 'OFF', searches), xbmc.LOGINFO)
        ia_results = []
        for search in searches:
            params = urllib.parse.urlencode({
                'q': search, 'fl[]': 'identifier,title,licenseurl,rights,creator,date,downloads',
                'rows': 50, 'page': 1, 'output': 'json', 'sort[]': 'downloads desc'
            })
            try:
                documents = web_json('https://archive.org/advancedsearch.php?' + params).get('response', {}).get('docs', [])
            except Exception as exc:
                xbmc.log('Retrovision MAGIC archive search: ' + repr(exc), xbmc.LOGWARNING)
                break
            results = []
            for document in documents:
                license_url = document.get('licenseurl') or ''
                if isinstance(license_url, list):
                    license_url = license_url[0] if license_url else ''
                title = first_text(document.get('title')) or document.get('identifier') or 'Untitled'
                if custom:
                    # No title/word gate on custom searches: everything the
                    # query returns is kept (collections and uploads alike)
                    # and relevance ranking below orders it.
                    pass
                elif not title_matches(title, phrase):
                    continue
                document['_license'] = first_text(license_url)
                document['_rights'] = first_text(document.get('rights'))
                document['title'] = title
                document['_unrestricted'] = bool(custom)
                results.append(document)
            if results:
                ia_results = results
                break
        externals = []
        if lock:
            # Open providers run only under a category lock: Wikimedia
            # Commons plus federated PeerTube, alongside the Archive.
            externals = commons_search(phrase) + peertube_search(phrase)
        if custom:
            merged = ia_results + externals
            merged.sort(key=lambda item: custom_result_score(item, custom),
                        reverse=True)
            return merged[:20]
        if lock:
            # Archive first, then the open providers: capping the Archive
            # share guarantees Commons/PeerTube stay visible in the list.
            return (ia_results[:20] + externals)[:25]
        return ia_results[:20]

    def archive_video_url(self, identifier, allow_short=False):
        try:
            metadata = web_json('https://archive.org/metadata/' + urllib.parse.quote(identifier))
        except Exception as exc:
            # A metadata flake must read as "no playable file", not escape up
            # through the tick loop and close the whole app.
            xbmc.log('Retrovision archive metadata: ' + repr(exc), xbmc.LOGWARNING)
            return None
        runtime = metadata_seconds((metadata.get('metadata') or {}).get('duration')
                                   or (metadata.get('metadata') or {}).get('runtime'))
        if runtime is not None and runtime < ARCHIVE_MIN_RUNTIME and not allow_short:
            # A 1-minute clip or short, not a movie: skip it and roll another.
            # Custom (unrestricted) picks keep shorts: a specific query may
            # only exist as clips.
            return None
        choices = []
        for file_info in metadata.get('files', []):
            name = file_info.get('name', '')
            try:
                size = int(file_info.get('size', 0))
            except (TypeError, ValueError):
                size = 0
            if name.lower().endswith(('.mp4', '.m4v')) and 1024 * 1024 < size <= ARCHIVE_MAX_FILE_SIZE:
                choices.append((0 if '512kb' in name.lower() else 1, size, name))
        if not choices:
            return None
        choices.sort()
        filename = choices[0][2]
        return 'https://archive.org/download/{}/{}'.format(urllib.parse.quote(identifier), urllib.parse.quote(filename))

    def result_video_url(self, result):
        # Direct open-provider URL when the result carries one (already
        # size-checked at search time); otherwise resolve via Archive metadata.
        if result.get('_file_url'):
            return result['_file_url']
        return self.archive_video_url(result['identifier'],
                                      allow_short=bool(result.get('_unrestricted')))

    def play_archive_result(self, result):
        video_url = self.result_video_url(result)
        if not video_url:
            raise ValueError('No Pi-compatible MP4 file was found for this item.')
        title = result['title']
        self.magic_show = {'name': title, '_query': title}
        self.magic_episodes = []
        self.magic_local = {}
        self.magic_availability = {}
        self.magic_active = True
        self.paused_at = None
        self.clock_delay = 0
        self.key = None
        self.setProperty('retro.tuning', '')
        self.setProperty('retro.mode', 'tv')
        self.setProperty('retro.playlabel', 'PAUSE')
        item = xbmcgui.ListItem(label=title, path=video_url)
        item.setInfo('video', {'title': title})
        item.setProperty('IsPlayable', 'true')
        self.player.play(video_url, item, windowed=True)
        source = {'commons': 'MAGIC  /  WIKIMEDIA COMMONS',
                  'peertube': 'MAGIC  /  PEERTUBE'}.get(result.get('_source'),
                                                        'MAGIC  /  LICENSED ARCHIVE')
        self.setProperty('retro.channel', source)
        self.setProperty('retro.program', title)
        self.setProperty('retro.remaining', 'INTERNET ARCHIVE  /  RIGHTS REVIEWED BY USER  /  CH +/- NEXT RESULT')
        self.show_banner()

    def confirm_and_play_archive_result(self, result):
        license_url = result.get('_license', '')
        if 'publicdomain' in license_url:
            # Covers both the Public Domain Mark and CC0 -- the uploader's own Archive.org
            # metadata already declares no rights are held, so there's nothing to confirm.
            self.play_archive_result(result)
            return True
        rights = result.get('_license') or result.get('_rights') or 'No rights statement was supplied.'
        creator = result.get('creator') or 'Unknown uploader/creator'
        if isinstance(creator, list):
            creator = ', '.join(str(value) for value in creator)
        approved = xbmcgui.Dialog().yesno('MAGIC / CHECK RIGHTS BEFORE PLAYING',
            '{}\n\nUPLOADER / CREATOR\n{}\n\nRIGHTS\n{}\n\nPlay only if you have permission or the work is lawful for you to access.'.format(
                result['title'], creator, rights), yeslabel='PLAY', nolabel='CANCEL')
        if approved:
            self.play_archive_result(result)
        return approved

    def offer_web_fallback(self, query):
        # Opt-in escape hatch when the licensed sources come up empty. The
        # warning is explicit: this leaves Retrovision's libraries, and the
        # search opens on the viewer's phone — the addon never fetches,
        # scrapes or plays outside video itself. Returns True on accept.
        if not xbmcgui.Dialog().yesno('MAGIC / NOTHING LICENSED FOUND',
                'The Internet Archive has nothing for "{}".\n\nSearch Google instead? '
                'This goes outside Retrovision to the web on your phone — '
                'only watch results you have the right to access.'.format(query),
                yeslabel='SEARCH WEB', nolabel='BACK'):
            return False
        self.web_fallback = {'query': query, 'url': web_search_url(query)}
        xbmcgui.Dialog().notification('MAGIC',
            'Web search ready — open the phone remote and tap the link.',
            xbmcgui.NOTIFICATION_INFO, 6000)
        return True

    def choose_archive_result(self, query, results=None):
        if results is None:
            results = self.archive_search(query)
        lock = getattr(self, 'category_lock', '')
        if not results:
            if lock:
                xbmcgui.Dialog().notification('MAGIC', 'No {} results for {}.'.format(lock, query),
                                               xbmcgui.NOTIFICATION_INFO, 5000)
                if xbmcgui.Dialog().yesno('MAGIC / NO {} RESULTS'.format(lock.upper()),
                        'Nothing in ' + lock + ' matched ' + query + '.  Change or clear the category lock?',
                        yeslabel='CHANGE', nolabel='BACK'):
                    if self.choose_category_lock():
                        return self.choose_archive_result(query)
            return self.offer_web_fallback(query)
        def rights_label(item):
            if item.get('_source') == 'commons':
                return 'WIKIMEDIA COMMONS'
            if item.get('_source') == 'peertube':
                return 'PEERTUBE'
            license_url = item.get('_license', '')
            if 'publicdomain' in license_url:
                return 'PUBLIC DOMAIN MARK'
            if 'creativecommons.org/licenses/' in license_url:
                return 'CREATIVE COMMONS'
            if item.get('_rights'):
                return 'RIGHTS NOTE'
            return 'RIGHTS NOT VERIFIED'
        labels = ['{}  [{}]'.format(item['title'], rights_label(item)) for item in results]
        title = 'MAGIC / ARCHIVE RESULTS' + (' / ' + lock.upper() if lock else '')
        selected = xbmcgui.Dialog().select(title, labels)
        if selected < 0:
            return True
        # The rest of this search's results become the CH +/- list -- each one still
        # gets its own rights confirmation the first time you land on it.
        self.magic_playlist = results
        self.magic_index = selected
        self.confirm_and_play_archive_result(results[selected])
        return True

    def magic_step(self, delta):
        """CH +/- while a MAGIC search is active: move within this search's results
        instead of leaving to a broadcast channel. Returns False if there's no active
        MAGIC playlist, so the caller can fall back to normal channel surfing."""
        if not self.magic_active or not self.magic_playlist:
            return False
        self.magic_index = (self.magic_index + delta) % len(self.magic_playlist)
        entry = self.magic_playlist[self.magic_index]
        if isinstance(entry, dict) and 'identifier' in entry:
            # Archive.org result: rights can differ per item, so this still confirms
            # before playing -- it just skips straight to that item's dialog.
            if not self.confirm_and_play_archive_result(entry):
                xbmcgui.Dialog().notification('MAGIC', 'Skipped. Press CH again for the next result.',
                                               xbmcgui.NOTIFICATION_INFO, 4000)
        else:
            self.play_magic_episode(entry)
        return True

    def play_magic_episode(self, episode):
        local = self.magic_local.get((episode.get('season'), episode.get('number')))
        if not local:
            available = self.magic_availability.get((episode.get('season'), episode.get('number')))
            message = ('Listed on Pluto TV; protected playback needs an official Pluto app.' if available else
                       'This episode is not in a connected legal library.')
            xbmcgui.Dialog().notification('MAGIC', message, xbmcgui.NOTIFICATION_INFO, 6000)
            return False
        self.magic_active = True
        self.paused_at = None
        self.clock_delay = 0
        self.key = None
        self.setProperty('retro.tuning', '')
        self.setProperty('retro.mode', 'tv')
        self.setProperty('retro.playlabel', 'PAUSE')
        title = local.get('title') or episode.get('name') or 'Episode'
        source = local.get('_source', 'CONNECTED LIBRARY')
        item = xbmcgui.ListItem(label=title, path=local['file'])
        item.setInfo('video', {'title': title, 'season': episode.get('season', 0), 'episode': episode.get('number', 0)})
        item.setProperty('IsPlayable', 'true')
        self.player.play(local['file'], item, windowed=True)
        self.setProperty('retro.channel', 'MAGIC  /  ' + self.magic_show['name'].upper())
        self.setProperty('retro.program', 'S{:02d}E{:02d}  {}'.format(episode.get('season') or 0, episode.get('number') or 0, title))
        self.setProperty('retro.remaining', source + '  /  CH +/- NEXT EPISODE')
        self.show_banner()
        return True

    def choose_magic_episode(self):
        seasons = sorted({episode.get('season') for episode in self.magic_episodes if episode.get('season') is not None})
        if not seasons:
            xbmcgui.Dialog().notification('MAGIC', 'No episode list was found.', xbmcgui.NOTIFICATION_INFO)
            return
        season_index = xbmcgui.Dialog().select('MAGIC / CHOOSE SEASON', ['SEASON {}'.format(number) for number in seasons])
        if season_index < 0:
            return
        season = seasons[season_index]
        episodes = [episode for episode in self.magic_episodes if episode.get('season') == season]
        rows = []
        for episode in episodes:
            item = self.magic_local.get((season, episode.get('number')))
            available = self.magic_availability.get((season, episode.get('number')))
            source = item.get('_source', '') if item else (available.get('_source', '') if available else '')
            rows.append('{} S{:02d}E{:02d}  {}{}'.format('PLAY' if item else '--- ', season, episode.get('number') or 0,
                        episode.get('name') or 'Untitled', '  [' + source + ']' if source else ''))
        selected = xbmcgui.Dialog().select('MAGIC / {} / SEASON {}'.format(self.magic_show['name'], season), rows)
        if selected >= 0:
            self.play_magic_episode(episodes[selected])

    def activate_show(self, show, query):
        """Load a TVmaze show's episodes and play whatever's available from a
        connected legal source. Called only after the user has picked this exact
        show from a list, never on a guessed match."""
        self.magic_show = show
        self.magic_show['_query'] = query
        self.magic_episodes = web_json('https://api.tvmaze.com/shows/{}/episodes?specials=1'.format(show['id']))
        self.magic_local = self.local_show_episodes(self.magic_show)
        self.magic_availability = {}
        pluto = self.pluto_show(self.magic_show)
        if pluto:
            pluto_episodes, pluto_available = self.pluto_episodes(pluto)
            self.magic_episodes = pluto_episodes
            self.magic_availability.update(pluto_available)
        playable = [episode for episode in self.magic_episodes if (episode.get('season'), episode.get('number')) in self.magic_local]
        if playable:
            playable.sort(key=lambda e: (e.get('season') or 0, e.get('number') or 0))
            unwatched = [episode for episode in playable if not self.magic_local[(episode.get('season'), episode.get('number'))].get('playcount')]
            chosen = (unwatched or playable)[0]
            # These playable episodes become the CH +/- list for this show.
            self.magic_playlist = playable
            self.magic_index = playable.index(chosen)
            self.play_magic_episode(chosen)
            source = self.magic_local[(chosen.get('season'), chosen.get('number'))].get('_source', 'connected source')
            xbmcgui.Dialog().notification('MAGIC', 'Playing from {}. CH +/- moves between episodes.'.format(source), xbmcgui.NOTIFICATION_INFO, 5000)
            return
        if not self.choose_archive_result(query):
            message = ('Episode list found on Pluto TV, but protected playback requires an official Pluto app.'
                       if self.magic_availability else 'Show found. No playable licensed video is connected yet.')
            xbmcgui.Dialog().notification('MAGIC', message, xbmcgui.NOTIFICATION_INFO, 6000)
            self.choose_magic_episode()

    def search_magic(self):
        keyboard = xbmc.Keyboard('', 'MAGIC / TYPE A SHOW, MOVIE, OR SHORT')
        keyboard.doModal()
        if not keyboard.isConfirmed() or not keyboard.getText().strip():
            return
        query = keyboard.getText().strip()
        self.web_fallback = None
        xbmcgui.Dialog().notification('MAGIC', 'Searching legal libraries...', xbmcgui.NOTIFICATION_INFO, 2500)
        results = web_json('https://api.tvmaze.com/search/shows?q=' + urllib.parse.quote(query))[:12]
        if not results:
            # No TV series matched (e.g. a standalone film or short like "Steamboat Willie").
            # Fall through to the same rights-checked Internet Archive search used below,
            # instead of giving up just because it isn't a TV show.
            if not self.choose_archive_result(query):
                xbmcgui.Dialog().notification('MAGIC', 'No matching show, movie, or short was found.',
                                               xbmcgui.NOTIFICATION_INFO, 6000)
            return
        labels = []
        for result in results:
            show = result['show']
            year = (show.get('premiered') or '')[:4]
            labels.append('{}{}'.format(show.get('name', 'Unknown'), '  (' + year + ')' if year else ''))
        selected = xbmcgui.Dialog().select('MAGIC / SELECT SHOW', labels)
        if selected < 0:
            return
        self.activate_show(results[selected]['show'], query)

    def magic(self):
        if not self.magic_show:
            selected = xbmcgui.Dialog().select('MAGIC',
                ['FIND A SHOW, MOVIE, OR SHORT', self.magic_lock_label(), 'INSTALL ADD-ONS FROM INBOX'])
            if selected == 0:
                self.search_magic()
            elif selected == 1:
                self.choose_category_lock()
            elif selected == 2:
                self.install_addons_from_inbox()
            return
        selected = xbmcgui.Dialog().select('MAGIC / ' + self.magic_show['name'],
            ['CHOOSE AN EPISODE', 'NEW SEARCH', self.magic_lock_label(), 'INSTALL ADD-ONS FROM INBOX', 'RETURN TO CHANNEL TV'])
        if selected == 0:
            self.choose_magic_episode()
        elif selected == 1:
            self.search_magic()
        elif selected == 2:
            self.choose_category_lock()
        elif selected == 3:
            self.install_addons_from_inbox()
        elif selected == 4:
            self.tune(self.channel)

    def handle(self, command, value):
        if command == 'exit':
            self.closed.set()
            self.close()
        elif command == 'home':
            self.magic_active = False
            self.surf_active = False
            self.mode = 'home'
            self.player.stop()
            self.key = None
            self.setProperty('retro.mode', 'home')
            self.setFocusId(100)
        elif command in ('tv', 'next', 'prev', 'channel'):
            # Broadcast channels are removed: every TV entry point rolls a
            # fresh random movie. Waiting-idle, mid-roll, or playing -- any CH
            # press (or TV re-entry) rerolls.
            if command in ('next', 'prev') and self.magic_step(1 if command == 'next' else -1):
                return
            self.enter_surf_mode()
            return
        elif command == 'controls':
            opened = self.getProperty('retro.controls') != 'yes'
            self.setProperty('retro.controls', 'yes' if opened else '')
            self.setFocusId(222 if opened else 204)
        elif command == 'magic':
            self.surf_active = False
            try:
                self.magic()
            except Exception as exc:
                xbmc.log('Retrovision MAGIC: ' + repr(exc), xbmc.LOGERROR)
                xbmcgui.Dialog().notification('MAGIC', 'Search failed. Check the network and try again.', xbmcgui.NOTIFICATION_ERROR, 5000)
        elif command == 'installaddons':
            self.install_addons_from_inbox()
        elif command == 'playpause' and self.mode == 'tv' and self.player.isPlayingVideo():
            if self.magic_active or self.surf_active:
                self.player.pause()
                speed = json_rpc('Player.GetProperties', {'playerid': 1, 'properties': ['speed']}).get('speed', 1)
                self.setProperty('retro.playlabel', 'PLAY' if speed == 0 else 'PAUSE')
            elif self.paused_at is None:
                self.paused_at = time.time()
                self.setProperty('retro.playlabel', 'PLAY')
            else:
                self.clock_delay += time.time() - self.paused_at
                self.paused_at = None
                self.setProperty('retro.playlabel', 'PAUSE')
            if not (self.magic_active or self.surf_active):
                self.player.pause()
        elif command in ('volumeup', 'volumedown', 'mute'):
            if command == 'mute':
                xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Application.SetMute','params':{'mute':'toggle'}}))
            else:
                result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Application.GetProperties','params':{'properties':['volume']}})))
                volume = max(0, min(100, result['result']['volume'] + (5 if command == 'volumeup' else -5)))
                xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Application.SetVolume','params':{'volume':volume}}))
        elif command == 'banner':
            self.show_banner()
        elif command == 'seek' and self.mode == 'tv' and not self.magic_active:
            if getattr(self, 'surf_idle', False):
                # The idle dial carries no timeline to seek.
                return
            if self.surf_active:
                # Land somewhere in the middle of whatever this reroll picked, not at 0:00.
                if self.player.isPlayingVideo():
                    total = self.player.getTotalTime()
                    if total > 30:
                        self.player.seekTime(random.uniform(total * 0.05, total * 0.85))
            else:
                clip, elapsed, _ = current_item(self.config['channels'][self.channel], self.config['media'], self.channel_time())
                if self.player.isPlayingVideo() and self.player.getPlayingFile() == clip['path']:
                    self.player.seekTime(elapsed)
        elif command == 'guide':
            if not self.config.get('channels'):
                xbmcgui.Dialog().notification('Retrovision', 'No channels yet. Surf RANDOM or add videos first.',
                                               xbmcgui.NOTIFICATION_INFO, 5000)
                return
            state = self.remote_state()
            rows = ['{:02d}  {}  |  {}'.format(c['id'],c['name'],c['now']) for c in state['channels']]
            selected = xbmcgui.Dialog().select('RETROVISION / CHANNEL GUIDE', rows, preselect=self.channel)
            if selected >= 0:self.tune(selected)
        elif command == 'about':
            xbmcgui.Dialog().textviewer('RETROVISION / PHONE REMOTE',
                'Open on the same Wi-Fi:\n'+self.remote_url+'\n\nPAIRING CODE: '+self.pin+
                '\n\nChoose channels and edit names/video order from your phone.\n\n'+
                'MAGIC sources: your Kodi library, Internet Archive results with a rights confirmation before playback, plus Wikimedia Commons and PeerTube results while a category lock is set, and Pluto availability listings. TVmaze supplies episode metadata.\n\n'+
                'While a MAGIC result is playing, CH +/- moves through that search\'s results instead of switching broadcast channels.\n\n'+
                'CH + past your last channel (or CH - before your first) lands on RANDOM: a random movie or episode from your own Kodi library, or an Internet Archive movie drawn from a random year so films from every era show up. Landing there always rolls a fresh pick; the next CH press keeps surfing into the channels. With no channel videos lined up, TV mode plays RANDOM directly.\n\n'+
                'Your channel clock continues while you watch something else. BACK returns to the selector.')
        elif command == 'save':
            self.config['channels'] = value
            save_json(CONFIG, self.config)
            self.channel %= len(value)
            self.key = None
        elif command == 'error':
            # No lineup means TV is RANDOM-only, so a dead file rerolls instead
            # of kicking back to the selector.
            if self.surf_active or not self.config.get('channels'):
                self.enter_surf_mode()
                xbmcgui.Dialog().notification('RANDOM', 'That file could not play. Trying another.', xbmcgui.NOTIFICATION_ERROR)
            elif self.magic_active:
                self.tune(self.channel)
                xbmcgui.Dialog().notification('MAGIC', 'That source could not play. Returned to channel TV.', xbmcgui.NOTIFICATION_ERROR)
            else:
                self.handle('home', None)
                xbmcgui.Dialog().notification('Retrovision', 'Video could not play. Returned to selector.', xbmcgui.NOTIFICATION_ERROR)
    def maybe_start_pick(self):
        """Roll the dice off the tick thread so buttons stay responsive while
        archive.org takes its time. Extra CH presses mid-roll are dropped."""
        if getattr(self, 'pick_running', False):
            return False
        self.pick_running = True
        threading.Thread(target=self._pick_thread, daemon=True).start()
        return True

    def _pick_thread(self):
        try:
            self.play_random_pick()
        finally:
            self.pick_running = False

    def tick(self):
        try:
            while not self.closed.is_set() and not self.monitor.abortRequested():
                try:
                    while True:
                        self.handle(*self.commands.get_nowait())
                except queue.Empty:
                    pass
                if self.closed.is_set():break
                now = time.monotonic()
                idle = getattr(self, 'surf_idle', False)
                in_window = now < self.tuning_until
                try:
                    playing = bool(self.player.isPlayingVideo())
                except Exception:
                    playing = False
                tuning = tuning_visible(self.mode, idle, self.tuning_until, playing, now)
                if self.mode == 'tv':
                    self.setProperty('retro.tuning', 'yes' if tuning else '')
                    if self.pending_surf and not idle and not in_window:
                        # One-shot per reroll: the dice roll off-thread so the
                        # buttons stay responsive while archive.org is slow.
                        self.pending_surf = False
                        self.maybe_start_pick()
                    if now > self.banner_until:self.setProperty('retro.banner', '')
                self.monitor.waitForAbort(0.04 if tuning else 0.12)
        except Exception as exc:
            xbmc.log('Retrovision: '+repr(exc), xbmc.LOGERROR)
            self.mode = 'home'
            self.player.stop()
            self.closed.set()
            self.close()
            xbmcgui.Dialog().notification('Retrovision', str(exc), xbmcgui.NOTIFICATION_ERROR)

    def shutdown(self):
        self.closed.set()
        if hasattr(self, 'worker'):self.worker.join(2)
        if self.mode == 'tv':self.player.stop()
        if self.server:self.server.shutdown();self.server.server_close()


home = xbmcgui.Window(10000)
if home.getProperty('Retrovision.Running') != 'yes':
    home.setProperty('Retrovision.Running', 'yes')
    app = None
    try:
        if not CONFIG.exists():
            save_json(CONFIG, json.loads((ROOT/'channels.example.json').read_text()))
        app = RetroTV('RetroTV.xml', str(ROOT), 'Default', '720p')
        app.doModal()
    finally:
        if app:app.shutdown()
        home.clearProperty('Retrovision.Running')
